/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// Random number module header:
// Declares functions to support random number sampling
// -------------------------------------------------------------------


// --------------------------------------------------- 
// Includes
// --------------------------------------------------- 

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include "alloc.h"
#include "io.h"
#include "random.h"
#ifndef _types_h
#define _types_h
#include "types.h"
#endif


// --------------------------------------------------- 
// Functions for sampling pseudo random numbers
// --------------------------------------------------- 

//use this first function to seed the random number generator, 
//call this before any of the other functions 

void initrand(int seed){ 
  if(seed>=0){
    srand(seed); 
  }
  else{
    srand((unsigned)(time(0))); 
  }

} 

void endrand(){
} 

// generates a pseudo-random integer between 0 and 32767 

int randint(){ 
  return rand(); 
} 



// generates a pseudo-random integer between 0 and max (both incl.) 

int randint(int max){ 
  return (rand() % (max+1)); 
} 


// generates a pseudo-random integer between min and max (both incl.) 

int randint(int min,int max){ 
  return min+(rand() % ((max-min)+1));
} 



// generates a pseudo-random float between 0.0 and 1.0 (0 not incl. but 1 is) 

float randfloat(){ 
  return (rand()+1)/(float(RAND_MAX)+1); 
} 




// generates a pseudo-random double between 0.0 and 1.0 (0 not incl. but 1 is) 

double randdouble(){ 
  return (rand()+1)/(double(RAND_MAX)+1); 
} 


// generates a pseudo-random double between from and to (from not incl. but to is) 

double randdouble(double from,double to){ 
  double r = (rand()+1)/(double(RAND_MAX)+1); 
  return from+(r*(to-from));
} 


// generates an array with 'num2choose' doubles between 0 
// and num2choosefrom-1 (both incl.) 

iArray *pick_numbers(int num2choose,int num2choosefrom){

  iArray *sug_nums = allocIntArray(num2choose);  
  if(num2choose==num2choosefrom){
    for(int i=0;i<num2choose;i++){
      sug_nums->array[i]=i;
    }
  }
  else{
    bool ischosen = false;
    iArray *all_nums = allocIntArray(num2choosefrom);
    int sug_num;
    for(int i=0;i<num2choose;i++){
      sug_num = randint(num2choosefrom-i-1);
      for(int j=0;j<=sug_num;j++){
	ischosen = all_nums->array[j];
	if(ischosen){
	  sug_num++;
	}
      }
      sug_nums->array[i] = sug_num;
      all_nums->array[sug_num] = 1;
    }
    killArray(all_nums);
  } 
   
  return sug_nums;

}



int pick_a_legal_number(int max_num, int illegal_numbers[], int num_illegal_numbers){

  // Mark illegal numbers
  iArray *all_nums = allocIntArray(max_num+1);
  for(int i=0; i<num_illegal_numbers;i++){
    all_nums->array[illegal_numbers[i]]=1;
  }

  int ischosen;
  int sug_num = randint(max_num-num_illegal_numbers);
  for(int j=0;j<=sug_num;j++){
    ischosen = all_nums->array[j];
    if(ischosen){
      sug_num++;
    }
  }
  
  killArray(all_nums);
  return sug_num;

}



// --------------------------------------------------- 
// Class to wrap random number generator
// --------------------------------------------------- 

DiscreteGen::DiscreteGen(int n1, double* prob)     // discrete generator
  					           // values on 0,...,n1-1
{
   Gen(n1, prob); val=0;
}

DiscreteGen::DiscreteGen(int n1, double* prob, double* val1){
   Gen(n1, prob); 
   val = new double[n1];
   for (int i=0; i<n1; i++) val[i]=val1[i];
}


void DiscreteGen::Gen(int n1, double* prob)
{
   n=n1;                                         // number of values
   p=new double[n]; ialt=new int[n];
 
   double rn = 1.0/n; 
   double px = 0; 
   int i;
   for (i=0; i<n; i++){ 
     p[i]=0.0; ialt[i]=-1; 
   }
   for (i=0; i<n; i++){
     double pmin=1.0; double pmax=-1.0; int jmin=-1; int jmax=-1;
     for (int j=0; j<n; j++){
       if (ialt[j]<0){
	 px=prob[j]-p[j];
	 if (pmax<=px) { pmax=px; jmax=j; }
	 if (pmin>=px) { pmin=px; jmin=j; }
       }
     }
     if ((jmax<0) || (jmin<0)) {
       printf("\nDiscrete number generator failed!\n");
       exit(1);
     }
     ialt[jmin]=jmax; px=rn-pmin; p[jmax]+=px; px*=n; p[jmin]=px;
     if ((px>1.00001)||(px<-.00001)){
       printf("\nProbabilities given to the discrete number generator do not sum to 1!\n");
       exit(1);
     }
   }
   if (px>0.00001){
     printf("\nProbabilities given to the discrete number generator do not sum to 1!\n");
     exit(1);
   }
}


DiscreteGen::~DiscreteGen()
{
   delete [] p; delete [] ialt; delete [] val;
}

double DiscreteGen::Next()                  // Next discrete random variable
{
  int i = (int)(n*randdouble()); 
  if (randdouble()<p[i]){
    i=ialt[i];
  }
  return val ? val[i] : (double)i;
}

