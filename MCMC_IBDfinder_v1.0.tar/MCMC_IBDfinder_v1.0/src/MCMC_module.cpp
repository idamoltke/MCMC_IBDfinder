/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// MCMC module: 
// Implements functionality to do MCMC for detecting IBD
//
// Implemented by Ida Moltke, fall 2007 - fall 2010 
// -------------------------------------------------------------------


// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#include <algorithm>
#include <cmath>
#include <fstream>
#include "alloc.h"
#include "io.h"
#include "HMM_module.h"
#include "random.h"
#include <set>
#ifndef _types_h
#define _types_h
#include "types.h"
#endif

using namespace std;


// -------------------------------------------------------------------
// Class for doing ordinary MCMC 
// -------------------------------------------------------------------

class IBD_MCMC{

public:

  // Functions

  // - chain administration functions
  IBD_MCMC(int init_k,iMatrix *init_genos,
	   dArray *init_snp_dists,
	   dMatrix *init_frac_table,iMatrix* init_zs,
	   double init_lam,double init_rho,
	   double eps,double temp);

  ~IBD_MCMC();
  
  // - info access functions
  void print_cur_pars(int i);
  void print_cur_IBD_states();
  double get_temp();
  double get_cur_loglike();
  double get_cur_loglike_cool();
  double convert2this_chains_temp(double loglike_cool);


  // - move functions
  int make_lambda_move();
  int make_rho_move();
  int make_window_lambda_move(double half_window_size);
  int make_window_rho_move(double half_window_size);
  int make_single_z_move();
  int make_1chr_region_z_move(int max_reg_size);
  int make_multichr_region_z_move(int max_reg_size);
  int make_1chr_border_z_move(int max_reg_size);
  int make_IBD_expansion_move(int max_len);
  int make_IBD_reduction_move(int max_len);
  int make_remove_nested_move(int max_len);
  int make_insert_nested_move(int max_len);
  int make_remove_seminested_move(int max_len);
  int make_insert_seminested_move(int max_len);
  int make_copy_move(int max_len);
  int make_undo_copy_move(int max_len);
  int make_1chr_IBD_block_state_change_move(int max_len);
  int make_move(int move_type,move_pars *pars);
  

  // Variables
  // - generel info 
  iMatrix *genos;
  dMatrix *frac_table;
  dArray *snp_dists;
  int k;
  int num_inds;
  int num_chrs;
  int num_snps;
  double inv_temp;

  // - state info
  iMatrix *cur_zs;
  lInfo *cur_like_info;
  double cur_lam;
  double cur_rho;

  // - help variables
  iMatrix *old_zs;
  iMatrix *sug_zs;
  
protected:

  // Functions
  // - help functions
  int make_par_move(int par);    
  int make_window_par_move(int par,double half_window_size);
  virtual int try_1chr_zregion_sug(int start, int end, int chr, double a_addent);
  virtual int try_zregion_sug(int start, int end, iArray *chrs, double a_addent);
  int find1chrIBDhorizontal(int chr, int locus, int *left,int *right);
  int find_IBD_vertical(int chr,int locus,iArray *chr_array);
  int find_IBD_horizontal(int chr, int locus, int *left,int *right,
			  int stopleft, int stopright);  
  int find_expansion_area(int chr,int locus,int *left,int *right,
			  iArray* chr_array);
  int find_reduction_area(int chr, int locus,int *left, int *right,
			  iArray *chr_array,bool *chr_is_only_defining);
  int find_num_overlaps(int left,int right,iArray *chr_array,int num_chrs_in_area);
  int find_num_ID_chrs(int chr,int reg_start,int reg_end,iArray *chr_set);
  int find_num_ID_chrs_comp(int chr,int reg_start,int reg_end,iArray *comp_chr_set);


  // Variables
  // - help variables
  iArray *yi;
  dMatrix *error_prob_table;  
  dMatrix *e_table_with_u; 
  dMatrix *e_table_no_u;   
  iArray *chr_array1;
  iArray *chr_array2;

};



// -------------------------------------------------------------------
// Chain administration
// -------------------------------------------------------------------


// Initialization of chain (all vars and datastructures)
// -------------------------------------------------------------------

IBD_MCMC::IBD_MCMC(int init_k,iMatrix *init_genos,
		   dArray *init_snp_dists,
		   dMatrix *init_frac_table,iMatrix* init_zs,
		   double init_lam,double init_rho,
		   double eps,double temp=1){
  
  // Init constants
  genos = init_genos;
  snp_dists = init_snp_dists;
  frac_table = init_frac_table;
  num_snps = genos->x;
  num_inds = genos->y;
  num_chrs = num_inds*2;
  k = init_k;
  inv_temp = 1/temp;

  // Init variables

  // - the current state
  cur_lam = init_lam;
  cur_rho = init_rho;
  cur_zs = init_zs;
 
  // - the error probabilities
  error_prob_table = make_error_prob_table(eps);

  // - the emission probability tables 
  e_table_with_u = make_e_table_with_u(num_snps,frac_table,error_prob_table);
  e_table_no_u = make_e_table_no_u(error_prob_table);

  // - help containers
  yi     = allocIntArray(k+1); // for faster calculation of emission
  old_zs =  allocIntMatrix(num_snps,num_chrs); 
  sug_zs =  allocIntMatrix(num_snps,num_chrs); 
  chr_array1 = allocIntArray(num_chrs); 
  chr_array2 = allocIntArray(num_chrs); 

  // - the likelihood info
  cur_like_info = allocLikeInfo(num_snps);
  try{
  cur_like_info->log_t = calc_t(0,num_snps-1,snp_dists,cur_zs,k,cur_lam,
				cur_rho,num_inds,cur_like_info->log_ts); 
  cur_like_info->log_e = calc_e(0,num_snps-1,genos,cur_zs,k,
				num_inds,frac_table,cur_like_info->log_es,
				yi,e_table_with_u,
				e_table_no_u);
  }catch(int w){  
    printf("Warning: initial zs has 0 likelihood!\n");
    exit(EXIT_FAILURE);
  } 

}



// Close down of chain (all vars and datastructures)
// -------------------------------------------------------------------

IBD_MCMC::~IBD_MCMC(){
  killMatrix(error_prob_table);
  killMatrix(e_table_with_u);
  killMatrix(e_table_no_u);
  killMatrix(old_zs);
  killMatrix(sug_zs);
  killArray(yi);
  killArray(chr_array1);
  killArray(chr_array2);
  killLikeInfo(cur_like_info);
}


// -------------------------------------------------------------------
// Chain info printing
// -------------------------------------------------------------------

// Print of lambda, rho and likelihood
// -------------------------------------------------------------------

void IBD_MCMC::print_cur_pars(int itnum){
  printf("> %d\t%.6f\t%.6f\t%.6f\t%.6f",itnum,cur_lam,cur_rho,
  	 cur_like_info->log_t,cur_like_info->log_e);
}


// Print cur_zs
// -------------------------------------------------------------------

void IBD_MCMC::print_cur_IBD_states(){
  print_matrix_tabsep(cur_zs);
}


// -------------------------------------------------------------------
// Chain info access
// -------------------------------------------------------------------

// Get log likelihood
// -------------------------------------------------------------------

double IBD_MCMC::get_cur_loglike(){
  return (cur_like_info->log_t+cur_like_info->log_e)*inv_temp;
}


double IBD_MCMC::get_cur_loglike_cool(){
  return (cur_like_info->log_t+cur_like_info->log_e);
}


double IBD_MCMC::convert2this_chains_temp(double loglike_cool){
  return loglike_cool*inv_temp;
}

// Get other info
// -------------------------------------------------------------------

double IBD_MCMC::get_temp(){
  return 1/inv_temp;
}



// -------------------------------------------------------------------
// The moves
// -------------------------------------------------------------------


// Functions used by many of the moves
// -------------------------------------------------------------------

// Evaluates regions in the sug_zs (same conseq reg in multiple chrs)
int IBD_MCMC::try_zregion_sug(int start, int end, iArray *changed_chrs, double a_addent=0.0){

  // test if region borders are valid
  if(start<0 or end>num_snps-1){
    printf("Region borders are not valid: start is %d and end is %d\n",start,end);
    exit(EXIT_FAILURE);
  }

  // find calculation borders
  int first_locus = start;
  int last_locus_e = end;
  int last_locus_t;
  
  if(end==num_snps-1)
    last_locus_t = end;
  else{
    last_locus_t = end+1;
  }

  // store current z and insert suggested region
  int chr;
  int num_changed_chrs = changed_chrs->x;
  for(int c=0;c<num_changed_chrs;c++){ 
    chr = changed_chrs->array[c];
    for(int i=start;i<=end;i++){
      old_zs->matrix[i][chr] = cur_zs->matrix[i][chr];
      cur_zs->matrix[i][chr] = sug_zs->matrix[i][chr];
    }  
  }


  // - transition and emission probs are calc for the suggested state 
  // (only the relevant part)  
  int accept = 1;
  double log_sug_part_t;
  double log_sug_part_e;
try{
  log_sug_part_t   = calc_t(first_locus,last_locus_t,snp_dists,cur_zs,k,cur_lam,
			    cur_rho,num_inds,cur_like_info->tmp_log_ts); 
  log_sug_part_e = calc_e(first_locus,last_locus_e,genos,cur_zs,k,
			  num_inds,frac_table,cur_like_info->tmp_log_es,
			  yi,e_table_with_u,e_table_no_u);
 }catch(int w){

    // if the likelihood of the suggested state is 0 
    // the move is immediately rejected and the current zs is restored

    for(int c=0;c<num_changed_chrs;c++){ 
      chr = changed_chrs->array[c];
      for(int i=start;i<=end;i++){
	cur_zs->matrix[i][chr] = old_zs->matrix[i][chr]; 
      }   
    } 
  accept = 0;
  }  
  if(accept!=0){
    // - transition and emission probs are calc for current state 
    double log_cur_part_t = 0.0;
    double log_cur_part_e = 0.0;
  
    for(int i=first_locus;i<=last_locus_t;i++){
      log_cur_part_t += (cur_like_info->log_ts)->array[i];
    }

    for(int i=first_locus;i<=last_locus_e;i++){
      log_cur_part_e += (cur_like_info->log_es)->array[i];
    }

    double log_sug_t = cur_like_info->log_t+log_sug_part_t-log_cur_part_t;
    double log_sug_e = cur_like_info->log_e+log_sug_part_e-log_cur_part_e;
    double sug_log_like = log_sug_t+log_sug_e;
    double cur_log_like = cur_like_info->log_t+cur_like_info->log_e;
    double a = min(0.0,inv_temp*(sug_log_like-cur_log_like+a_addent));
    double U = randdouble();
    
    // if it is accepted the cur_like_info is updated
    if(U < exp(a)){
      cur_like_info->log_t = log_sug_t;
      cur_like_info->log_e = log_sug_e;

      for(int i=first_locus;i<=last_locus_t;i++){
	(cur_like_info->log_ts)->array[i] = (cur_like_info->tmp_log_ts)->array[i];
      }

      for(int i=first_locus;i<=last_locus_e;i++){
	(cur_like_info->log_es)->array[i] = (cur_like_info->tmp_log_es)->array[i];
      }
      accept = 1;
    }
    // else the current z is restored
    else{
      for(int c=0;c<num_changed_chrs;c++){ 
	chr = changed_chrs->array[c];
	for(int i=start;i<=end;i++){
	  cur_zs->matrix[i][chr] = old_zs->matrix[i][chr]; 
	}   
      } 
      accept = 0;
    }
  }
  return accept;
}



// Evaluates regions in the sug_zs (conseq reg in one chr)
int IBD_MCMC::try_1chr_zregion_sug(int start, int end, int chr, double a_addent=0.0){
  
  // test if region borders are valid
  if(start<0 or end>num_snps-1){
    printf("Region borders are not valid: start is %d and end is %d\n",start,end);
    exit(EXIT_FAILURE);
  }
  // find calculation borders
  int first_locus = start;
  int last_locus_e = end;
  int last_locus_t;
  
  if(end==num_snps-1)
    last_locus_t = end;
  else{
    last_locus_t = end+1;
  }
  
  // - transition and emission probs are calc for current state 
  // (only the relevant part)   
  double log_cur_part_t = calc_t_1chr(first_locus,last_locus_t,snp_dists,cur_zs,k,cur_lam,
				      cur_rho,num_inds,cur_like_info->tmp_log_ts,chr); 
  
  double log_cur_part_e = 0.0;
  for(int i=first_locus;i<=last_locus_e;i++){
    log_cur_part_e += (cur_like_info->log_es)->array[i];
  }

  // - store current zs and make new from suggested region
  for(int i=start;i<=end;i++){
    old_zs->matrix[i][chr] = cur_zs->matrix[i][chr];
    cur_zs->matrix[i][chr] = sug_zs->matrix[i][chr];
  }  

  // - transition and emission probs are calc for the suggested zs
  // (only the relevant part)
  int accept=1;
  double log_sug_part_t;
  double log_sug_part_e;
  try{  
  log_sug_part_t = calc_t_1chr(first_locus,last_locus_t,snp_dists,cur_zs,k,cur_lam,
			       cur_rho,num_inds,cur_like_info->tmp2_log_ts,chr); 
  log_sug_part_e = calc_e(first_locus,last_locus_e,genos,cur_zs,k,
			  num_inds,frac_table,cur_like_info->tmp_log_es,
			  yi,e_table_with_u,e_table_no_u);
  }catch(int w){
  // if the likelihood of the suggested state is 0 
  // the move is immediately rejected and the current zs is restored
    for(int i=start;i<=end;i++){
      cur_zs->matrix[i][chr] = old_zs->matrix[i][chr];
    }    
    accept = 0;
  }  
  if(accept!=0){
  // else the suggested state is accepted with prob min(1,cur_like,sug_like)
    double log_sug_t = cur_like_info->log_t+log_sug_part_t-log_cur_part_t;
    double log_sug_e = cur_like_info->log_e+log_sug_part_e-log_cur_part_e;
    double sug_log_like = log_sug_t+log_sug_e;
    double cur_log_like = cur_like_info->log_t+cur_like_info->log_e;
    double a = min(0.0,inv_temp*(sug_log_like-cur_log_like+a_addent));

    // if it is accepted the cur_like_info is updated
    double U = randdouble();
    
    if(U < exp(a)){
      cur_like_info->log_t = log_sug_t;
      cur_like_info->log_e = log_sug_e;
      double diff_log_part_t;
      for(int i=first_locus;i<=last_locus_t;i++){
	diff_log_part_t = (cur_like_info->tmp2_log_ts)->array[i]-(cur_like_info->tmp_log_ts)->array[i];
	(cur_like_info->log_ts)->array[i] += diff_log_part_t;
      }
      
      for(int i=first_locus;i<=last_locus_e;i++){
	(cur_like_info->log_es)->array[i] = (cur_like_info->tmp_log_es)->array[i];
      }
      accept = 1;
    }
    // if else old zs is restored
    else{
      for(int i=start;i<=end;i++){
	cur_zs->matrix[i][chr] = old_zs->matrix[i][chr];
      }         
      accept = 0;
    }
  }

  return accept;

}





// The simplest parameter move:
// (a new parameter is suggested uniformly between 0 and 1)
// -------------------------------------------------------------------


int IBD_MCMC::make_par_move(int par){    
  int accept = 1;
  double *cur_par;
  double sug_par,log_sug_t,a,U;
  dArray *tmp; 
 
  // suggest new par
  sug_par = randdouble(); 
  
  // evaluate new par
  // - calculate transition probability given the suggested par
  try{
  if(par==0){
    cur_par = &cur_lam;
    log_sug_t = calc_t(0,num_snps-1,snp_dists,cur_zs,k,sug_par,cur_rho,
		       num_inds,cur_like_info->tmp_log_ts);
  }
  else{
    cur_par = &cur_rho;
    log_sug_t = calc_t(0,num_snps-1,snp_dists,cur_zs,k,cur_lam,sug_par,
		       num_inds,cur_like_info->tmp_log_ts);
  }
  }catch(int w){
    // - if the transition prob is 0 the move is immediately rejected 
    accept = 0;
  }
  if(accept!=0){

    // - else it is accepted with probability min(1,sug_t/cur_t)
    a = min(0.0,inv_temp*(log_sug_t-cur_like_info->log_t));
    U = randdouble();

    if(U < exp(a)){
      // if it is accepted: cur_like_info and cur_par is updated
      cur_like_info->log_t = log_sug_t;
      tmp = cur_like_info->log_ts;
      cur_like_info->log_ts = cur_like_info->tmp_log_ts; 
      cur_like_info->tmp_log_ts = tmp;
      *cur_par = sug_par;
      accept = 1;
    }
    else{
      accept = 0;
    }
    
  }
  // in any case the accept status is returned 
  return accept; 
}


  
int IBD_MCMC::make_lambda_move(){
  return make_par_move(0);
} 


int IBD_MCMC::make_rho_move(){
  return make_par_move(1);
} 



// The window parameter move:
// (a new parameter a suggested uniformly in a window around the 
//  current value)
// -------------------------------------------------------------------

int IBD_MCMC::make_window_par_move(int par,double half_window_size=0.05){

  int accept=1;
  double *cur_par;
  double sug_par,log_sug_t,lborder,rborder,a,U;
  dArray *tmp; 

  // suggest new par
  if(par==0){
    cur_par = &cur_lam;
  }
  else{
    cur_par = &cur_rho;
  }
  // - window is determined
  lborder = *cur_par-half_window_size;
  rborder = *cur_par+half_window_size;

  // - par is suggested in window
  sug_par = randdouble(lborder,rborder);
    
  // - if the suggested par is not in the interval [0,1]
  //   it is corrected by mirroring 
  if(sug_par<0){
    sug_par = -1*sug_par;
  }
  else{
    if(sug_par>1){
      sug_par = 2-sug_par;
    }
  }

  // evaluate new par
  // - calculate transition probability given the suggested par
  try{
  if(par==0){
    log_sug_t = calc_t(0,num_snps-1,snp_dists,cur_zs,k,sug_par,cur_rho,
		       num_inds,cur_like_info->tmp_log_ts);
  }
  else{
    log_sug_t = calc_t(0,num_snps-1,snp_dists,cur_zs,k,cur_lam,sug_par,
 		       num_inds,cur_like_info->tmp_log_ts);
  }
  }catch(int w){
  // - if the transition prob is 0 the move is immediately rejected 
    accept = 0;
  }

  // - else it is accepted with probability min(1,sug_t/cur_t)
  if(accept!=0){
    a = min(0.0,inv_temp*(log_sug_t-cur_like_info->log_t));
    U = randdouble();

    if(U < exp(a)){
      // if it is accepted cur_like_info and cur_par is updated
      cur_like_info->log_t = log_sug_t;
      tmp = cur_like_info->log_ts;
      cur_like_info->log_ts = cur_like_info->tmp_log_ts; 
      cur_like_info->tmp_log_ts = tmp;
      *cur_par = sug_par;
      accept = 1;
    }
    else{
      accept = 0;
    }
  }

  // in any case the accept status is returned 
  return accept;
}



int IBD_MCMC::make_window_lambda_move(double half_window_size=0.05){
  return make_window_par_move(0,half_window_size);
}    


int IBD_MCMC::make_window_rho_move(double half_window_size=0.05){
  return make_window_par_move(1,half_window_size);
}    



// The simplest state (z) move:
// (a chromosome, a locus and a new state is picked uniformly)
// -------------------------------------------------------------------

int IBD_MCMC::make_single_z_move(){
    
  // pick locus uniformly
  int sug_locus = randint(num_snps-1);

  // pick chromosome uniformly
  int sug_chr = randint(num_inds*2-1);

  // suggest new z (different from the current)
  int cur_z = cur_zs->matrix[sug_locus][sug_chr];
  int sug_z = randint(k-1);
  if(sug_z == cur_z){
    sug_z = k;
  }
  sug_zs->matrix[sug_locus][sug_chr]=sug_z;

  // evaluate it
  int accept = try_1chr_zregion_sug(sug_locus,sug_locus,sug_chr);
  return accept;

}



// The one chromosome region state (z) move:
// (1 chromosome, a region and a state addend is picked uniformly)
// -------------------------------------------------------------------

int IBD_MCMC::make_1chr_region_z_move(int max_reg_size=10){

  // pick region length uniformly from 1 to max_reg_size
  int reg_len = randint(1,max_reg_size);

  // pick region start uniformly from 0 to num_snps-region length
  int sug_reg_start = randint(num_snps-reg_len);

  // pick chromosome uniformly
  int sug_chr = randint(num_inds*2-1);

  // suggest new z (different from the current)
  int addend = randint(1,k);

  int old_z;
  for(int i=0;i<reg_len;i++){
    old_z = cur_zs->matrix[sug_reg_start+i][sug_chr];
    sug_zs->matrix[sug_reg_start+i][sug_chr] = (old_z+addend)%(k+1);
  }  

  // evaluate it
  int accept = try_1chr_zregion_sug(sug_reg_start,sug_reg_start+reg_len-1,sug_chr);
  return accept;

}


// The multi chromosome region state (z) move:
// (# of chromosomes, a region and a state addend is picked uniformly)
// -------------------------------------------------------------------

int IBD_MCMC::make_multichr_region_z_move(int max_reg_size=10){

  // pick region length uniformly from 1 to max_reg_size
  int reg_len = randint(1,max_reg_size);

  // pick region start uniformly from 0 to num_snps-region length
  int sug_reg_start = randint(num_snps-reg_len);

  // pick number of chromosomes
  int sug_num_chrs = randint(1,num_chrs-1);

  // pick chromosomes uniformly
  iArray *sug_chrs = pick_numbers(sug_num_chrs,num_chrs);

  // suggest addent for making new z (different from the current)
  int addend = randint(1,k);

  // make suggested region
  int old_z;
  
  int sug_chr; 
  for(int c=0;c<sug_num_chrs;c++){ 
    sug_chr = sug_chrs->array[c];
    for(int i=0;i<reg_len;i++){
      old_z = cur_zs->matrix[sug_reg_start+i][sug_chr];
      sug_zs->matrix[sug_reg_start+i][sug_chr] = (old_z+addend)%(k+1);
    }  
  }

  // test if suggestion is 
  int accept = try_zregion_sug(sug_reg_start,sug_reg_start+reg_len-1,sug_chrs);
  killArray(sug_chrs);
  return accept;

}


// The border (z) move:
// (a chromosome, a border,a dir and a mv-length is picked uniformly)
// -------------------------------------------------------------------

void flip(iMatrix *cur_zs,iMatrix *sug_zs,int chr,int start,int dir,int reg_len){
  
  int cur = start-dir;
  int cur_IBD = cur_zs->matrix[cur][chr];
  int next_IBD = cur_zs->matrix[cur+dir][chr];
  int tmp;
  for(int c=0; c<reg_len;c++){  
    sug_zs->matrix[cur+dir][chr]=cur_IBD;
    cur+=dir;
    tmp = cur_zs->matrix[cur+dir][chr];
    if(tmp!=next_IBD){
      cur_IBD = next_IBD;
      next_IBD = tmp;
    }
  }
}


iArray* find_borders(iMatrix *cur_zs,int sug_chr){

  // - find borders
  int num_snps = cur_zs->x;
  iArray *borders = allocIntArray(num_snps);
  int num_borders = 0;
  int prev_z;
  int cur_z = cur_zs->matrix[0][sug_chr]; 

  for(int i=1;i<num_snps;i++){
    prev_z = cur_z;
    cur_z = cur_zs->matrix[i][sug_chr]; 
    if(cur_z!=prev_z){
      num_borders++;
      borders->array[num_borders]=i;
    }
  }

  borders->array[0]=num_borders;
  return borders;
}


void find_start_len_and_dir(iMatrix *cur_zs,int sug_chr,iArray *borders,
			    int sug_border,int sug_reg_len, int sug_dir,
			    int *reg_start, int *reg_len, int *dir){

  // init info needed to find start, direction and stop info
  int num_snps = cur_zs->x;
  int num_borders = borders->array[0];
  int sug_reg_start,last_border_in_cur_dir;
  if(sug_dir==1){
    sug_reg_start = borders->array[sug_border];
    last_border_in_cur_dir = num_borders;
  }
  else{
    sug_dir = -1;
    last_border_in_cur_dir = 1;
    sug_reg_start = borders->array[sug_border]-1;
  }
  int cur_reg_stop = sug_reg_start+(sug_reg_len-1)*sug_dir;
  int cur_border = sug_border;
  int cur_border_coords = borders->array[cur_border];
  int cur_dir = sug_dir;
  bool more_dirs = false;

  // find stop info
  while(true){
    // if the current border it is the last border  
    if(cur_border==last_border_in_cur_dir){
      // if reg_stop is inside z the reg_stop has been found
      if(cur_reg_stop>0 and cur_reg_stop<(num_snps-1)){
	break;
      }
      // else the search continues in the other direction
      else{
	cur_dir =  cur_dir*(-1);
	if(cur_dir==1){
	  cur_reg_stop = -1*cur_reg_stop+1;
	}
	else{
	  cur_reg_stop = 2*(num_snps-2)-cur_reg_stop+1;
	}
      last_border_in_cur_dir = 1+num_borders-last_border_in_cur_dir;
      }	
      more_dirs = true;
    }
    // if the current border is not the last look at next border
    else{
      cur_border += cur_dir;
      cur_border_coords = borders->array[cur_border];
    }    

    // check if stop is before next border
    if((cur_dir==+1 and cur_reg_stop<(cur_border_coords-1)) or
       (cur_dir==-1 and cur_reg_stop>cur_border_coords) or 
       (more_dirs and cur_dir==1 and cur_reg_stop<cur_border_coords and sug_border>=cur_border) or       
       (more_dirs and cur_dir!=1 and cur_reg_stop==cur_border_coords and sug_border<=cur_border )){            

      break;
    }
    // if not stop is increased by one since border is to be skipped
    else{
      if(!(more_dirs and cur_border==sug_border)){
	cur_reg_stop += cur_dir;
      }
    }    
  }
 
  if(cur_reg_stop==sug_reg_start){
    *dir = sug_dir;
  }
  else{
    if(cur_reg_stop<sug_reg_start){
      *dir = -1;
    }
    else{
    *dir = 1;
    }
  }
  if(*dir==sug_dir){
    *reg_start = sug_reg_start;
  }
  else{
    *reg_start = sug_reg_start+*dir;
  }
  *reg_len = abs(cur_reg_stop-*reg_start)+1;
}



int IBD_MCMC::make_1chr_border_z_move(int max_reg_size=10){
  
  // pick chromosome uniformly
  int sug_chr = randint(num_chrs-1);
  
  // pick border uniformly
  // - find borders
  iArray *borders = find_borders(cur_zs,sug_chr);
  int num_borders = borders->array[0];

  // - pick uniformly between them
  int accept;
  if(num_borders==0 or num_borders==(num_snps-1)){
    accept = 0;
    killArray(borders);
    return accept;
  }
  int sug_border = randint(1,num_borders); 

  // pick direction uniformly 
  int orig_sug_dir = randint(1);  

  // pick move distance (# num nonborders) uniformly from 1 to max_reg_size
  int move_len = randint(1,max_reg_size);

  // find corresponding region start, len and direction
  int sug_reg_start,reg_len,sug_dir;
  find_start_len_and_dir(cur_zs,sug_chr,borders,sug_border,move_len,
			 orig_sug_dir,&sug_reg_start,&reg_len,&sug_dir);
  flip(cur_zs,sug_zs,sug_chr,sug_reg_start,sug_dir,reg_len);
  
  // test that nothing odd is going on  
  iArray *bordersx = find_borders(cur_zs,sug_chr);
  int num_bordersx = bordersx->array[0];
  killArray(bordersx);
  if(num_borders!=num_bordersx){
    printf("Warning: wrong number of borders after flip!!!");
    printf("\nBefore: %d \n",num_borders);
    printf("After %d\n",num_bordersx);
    print_matrix(cur_zs,sug_chr);
    killArray(borders);
    exit(EXIT_FAILURE);
  }
  killArray(borders);

  // test the suggested change
  int first_locus;
  if(sug_dir==1){
    first_locus = sug_reg_start;
  }
  else{
    first_locus = sug_reg_start-reg_len+1;
  } 
  
  accept = try_1chr_zregion_sug(first_locus,first_locus+reg_len-1,sug_chr);
  return accept;

}



// A move that can expand and reduce an IBD set vertically
// -------------------------------------------------------------------

int IBD_MCMC::find_IBD_vertical(int chr,int locus,iArray *chr_array){

  int IBD = cur_zs->matrix[locus][chr];
  int num_chrs_IBD = 0;

  // run through all chromosomes
  for(int c=0;c<num_chrs;c++){
    // if a chromosome is in the IBD it is put in the beginning of chrs 
    if(IBD==cur_zs->matrix[locus][c]){
      chr_array->array[num_chrs_IBD++]=c;
    }
    // else it is put in the end of array
    else{
      chr_array->array[num_chrs-c+num_chrs_IBD-1]=c;
    }
  }  
  return num_chrs_IBD;
}


int IBD_MCMC::find_IBD_horizontal(int chr, int locus, int *left,int *right,
				  int stopleft, int stopright){
  
  // NB borders are assumed to be ok!
  int IBD = cur_zs->matrix[locus][chr];
  
  // find left border
  int stopped_early_l = 0;
  *left = locus;
  for(int l=locus;l>=stopleft;l--){
    if(!(IBD==cur_zs->matrix[l][chr])){
      *left = (l+1);
      stopped_early_l=1;
      break;
    }
    else{
      *left = l;
    }
  }
  
  // find right border
  int stopped_early_r = 0;
  *right = locus;
  for(int l=locus;l<=stopright;l++){
    if(!(IBD==cur_zs->matrix[l][chr])){
      *right = (l-1);
      stopped_early_r=2;
      break;
    }
    else{
      *right = l;
    }
    
  }
  return (stopped_early_l+stopped_early_r);
}



int IBD_MCMC::find_expansion_area(int chr,int locus,int *left,
			    int *right,iArray *chr_array){

  int num_chrs_in_area = find_IBD_vertical(chr,locus,chr_array);
  int cur_left = 0;
  int cur_right = num_snps-1;
  int cur_chr;
  int border_state;
  
  for(int i=0;i<num_chrs_in_area;i++){
    cur_chr = chr_array->array[i];
    border_state = find_IBD_horizontal(cur_chr,locus,left,right,cur_left,cur_right);
    if(border_state==1 or border_state==3){
      // closer left border found
      cur_left = *left;
    }
    if(border_state==2 or border_state==3){
      // closer right border found
      cur_right =*right;
    }
  }

  *left  = cur_left;
  *right = cur_right;
  return num_chrs_in_area;
}      


int IBD_MCMC::find_reduction_area(int chr, int locus,int *left, 
				  int *right,iArray *chr_array, 
				  bool *chr_is_only_defining){
  
  int cur_left = 0;
  int cur_right = num_snps-1;
  int this_chr_left;
  int this_chr_right;
  int tmp_left;
  int tmp_right;
  int cur_chr;
  int border_state;

  // Find borders
  // - find the given chrs borders
  find_IBD_horizontal(chr,locus,&this_chr_left,&this_chr_right,cur_left,cur_right);
  
  // - if chr is only chr we are done
  int num_chrs_in_area = find_IBD_vertical(chr,locus,chr_array);
  
  if(num_chrs_in_area==1){
    *left =this_chr_left;
    *right=this_chr_right;
    *chr_is_only_defining = true;
    return num_chrs_in_area;
  }

  // - otherwise find the area borders for all other chrs
      
  for(int i=0;i<num_chrs_in_area;i++){
    cur_chr = chr_array->array[i];
    if(cur_chr==chr){
      continue;
    }  
    
    border_state = find_IBD_horizontal(cur_chr,locus,&tmp_left,
				       &tmp_right,cur_left,cur_right);
    
    if(border_state==1 or border_state==3){
      // closer left border found
      cur_left = tmp_left;
    }
    
    if(border_state==2 or border_state==3){
      // closer right border found
      cur_right = tmp_right;
    }
  }
  
  // - check if the chr is the only defining border either to the left 
  //   or to the right and set both border plus the is_only_defining 
  //   variable accordingly 
  bool is_defining_left,is_defining_right;

  // chr is only chr to define left border?
  if(this_chr_left<=cur_left){
    is_defining_left = false;
    *left=cur_left;
  }
  else{
    is_defining_left = true;
    *left=this_chr_left;
  }

  // chr is only chr to define right border?
  if(this_chr_right>=cur_right){
    is_defining_right = false;
    *right=cur_right;
  }
  else{
    is_defining_right = true;
    *right=this_chr_right;
  }

  *chr_is_only_defining = (is_defining_left||is_defining_right);

  return num_chrs_in_area;

}      

int IBD_MCMC::find_num_overlaps(int left,int right,iArray *chr_array,
				int num_chrs_in_area){
  
  int num_overlaps = 0;
  int IBD = cur_zs->matrix[left][chr_array->array[0]];
  
  
  for(int l=left;l<=right;l++){
    for(int c=num_chrs_in_area;c<num_chrs;c++){
      if(IBD==cur_zs->matrix[l][chr_array->array[c]]){
	num_overlaps++;
	break;
      }
    }
  }
     
  return num_overlaps;
}




int IBD_MCMC::make_IBD_expansion_move(int max_len){

  int accept;

  // Making proposal
  
  // - pick locus uniformly
  int sug_locus = randint(num_snps-1);
   
  // - pick chromosome uniformly
  int sug_chr = randint(num_chrs-1);
 
  // - find IBD area of interest
  int exp_area_left,exp_area_right;
  int num_chrs_in_exp_area = find_expansion_area(sug_chr,sug_locus,
						 &exp_area_left,&exp_area_right,
						 chr_array1);
  
  // - if area can not be expanded the move is rejected
  if(num_chrs_in_exp_area==num_chrs){
    accept = 0;
    return accept;
  }

  if((exp_area_right-exp_area_left)>max_len){
    accept = 0;
    return accept;
  }

  int IBD_state_exp_area = cur_zs->matrix[sug_locus][sug_chr];
  
  // - pick chromosome to expand with
  //  (uniformly between the chromosomes not in the IBD area)
  int num_other_chrs = num_chrs-num_chrs_in_exp_area;
  int sug_exp_chr = chr_array1->array[num_chrs_in_exp_area+randint(num_other_chrs-1)];
  
  // - check sug_exp_chr has same state from sug_left to sug_right otherwise reject move
  int IBD_state_exp_chr = cur_zs->matrix[exp_area_left][sug_exp_chr];
  for(int i=exp_area_left;i<=exp_area_right;i++){
    if(!(IBD_state_exp_chr==cur_zs->matrix[i][sug_exp_chr])){
      accept=0;
      return accept;
    }
  } 
  
  // - make proposal where IBD_area is expanded to sug_exp_chr
  for(int i=exp_area_left;i<=exp_area_right;i++){
    sug_zs->matrix[i][sug_exp_chr]=IBD_state_exp_area;
  }

  // Evaluate it
  // - find a_addent
  double a_addent;
  bool sug_exp_chr_is_area_defining;
  int red_area_left,red_area_right;
  int num_chrs_in_red_area = find_reduction_area(sug_exp_chr,sug_locus,
						 &red_area_left,
						 &red_area_right,
						 chr_array2,
						 &sug_exp_chr_is_area_defining);
  
  a_addent = log(num_other_chrs)-log(num_chrs_in_exp_area*k);
  accept = try_1chr_zregion_sug(exp_area_left,exp_area_right,
				sug_exp_chr,a_addent);

  return accept;
  
}
  
  

int IBD_MCMC::make_IBD_reduction_move(int max_len){

  int accept;
  
  // Making proposal

  // - pick locus uniformly
  int sug_locus = randint(num_snps-1);
    
  // - pick chromosome uniformly
  int sug_chr = randint(num_chrs-1);
    
  // - check if its legal otherwise reject entire move
  int red_left,red_right;
  bool sug_chr_is_area_defining;
  int num_chrs_in_red_area = find_reduction_area(sug_chr,sug_locus,
						 &red_left,&red_right,
						 chr_array1,
						 &sug_chr_is_area_defining);  
  
  if(sug_chr_is_area_defining){
    accept = 0;
    return accept;
  }

  if((red_right-red_left)>max_len){
    accept = 0;
    return accept;
  }
  

    
  // Give region in the chr new IBD state
  // - find new IBD state
  int red_area_IBD = cur_zs->matrix[sug_locus][sug_chr];
  int sug_new_IBD = randint(k-1);
  if(sug_new_IBD == red_area_IBD){
    sug_new_IBD = k;
  }
  
  for(int i=red_left;i<=red_right;i++){
    sug_zs->matrix[i][sug_chr]=sug_new_IBD;
  }

  // Evaluate it  
  
  // - calc a_addent accordingly
  double a_addent = (log(k*(num_chrs_in_red_area-1))-
		     log(num_chrs-(num_chrs_in_red_area-1)));    
  
   
  accept = try_1chr_zregion_sug(red_left,red_right,sug_chr,a_addent);

  return accept;
}



// The nested IBD (z) move:
// (An IBD fully contained in another IBD is removed or added (chr level))
// -------------------------------------------------------------------


int IBD_MCMC::find1chrIBDhorizontal(int chr, int locus, 
				    int *left, int *right){

  int IBD = cur_zs->matrix[locus][chr];
  int cur_len = 0;

  // find left border
  *left = locus;
  for(int l=locus;l>=0;l--){
    if(!(IBD==cur_zs->matrix[l][chr])){
      *left = (l+1);
      break;
    }
    else{
      cur_len++;
      *left = l;
    }
  }
  
  // find right border
  *right = locus;
  for(int l=(locus+1);l<num_snps;l++){
    if(!(IBD==cur_zs->matrix[l][chr])){
      *right = (l-1);
      break;
    }
    else{
      cur_len++;
      *right = l;
    }
  }

 return cur_len;

}


int IBD_MCMC::make_remove_nested_move(int max_len){

  int accept;
  
  // pick chr
  int sug_chr = randint(num_chrs-1);
  
  // pick IBD
  int left,right;
  int sug_locus = randint(num_snps-1);
  int len = find1chrIBDhorizontal(sug_chr,sug_locus,&left,&right);

  // check if its legal otherwise reject entire move
  if(len>max_len or left==0 or right==(num_snps-1)){
    accept = 0;
    return accept;
  }
 
  if(!(cur_zs->matrix[(left-1)][sug_chr]==
       cur_zs->matrix[(right+1)][sug_chr])){
    accept = 0;
    return accept;
  }
  
  // if it is legal we attempt to make the move
  // - the nested IBD is removed
  int neighbor_IBD = cur_zs->matrix[(left-1)][sug_chr];
  for(int i=left;i<=right;i++){
    sug_zs->matrix[i][sug_chr] = neighbor_IBD;
  }

  // Evaluate it  
  double a_addent =  -log(max_len*len*k);
  accept = try_1chr_zregion_sug(left,right,sug_chr,a_addent);
  return accept;

}
  


int IBD_MCMC::make_insert_nested_move(int max_len){

  int accept;

  // pick chr
  int sug_chr = randint(num_chrs-1);
    
  // pick IBD start
  int sug_locus = randint(num_snps-1);
  
  // pick IBD length
  int sug_len = randint(1,max_len);
  
  // check if its legal otherwise reject entire move
  int left = sug_locus;
  int right = sug_locus+sug_len-1;
  
  // - if out of matrix
  if(left==0 or right>=(num_snps-1)){
    accept = 0;
    return accept;
  }
  
  // - not nested in one IBD
  int IBD=(cur_zs->matrix[left-1][sug_chr]);
  for(int i=left;i<=(right+1);i++){
    if(!(IBD==cur_zs->matrix[i][sug_chr])){
      accept = 0;
      return accept;
    }
  }
  
  // if it is legal we attempt to make the move
  // - nested IBD is inserted
  int new_IBD = randint(k-1);
  if(new_IBD==IBD){
    new_IBD=k;
  }
  
  for(int i=left;i<=right;i++){
    sug_zs->matrix[i][sug_chr] = new_IBD;
  }

  // Evaluate it  
  double a_addent = log(max_len*sug_len*k);
  accept = try_1chr_zregion_sug(left,right,sug_chr,a_addent);
  return accept;

}



// The seminested IBD (z) move:
// (An IBD between two diff other IBDs is inclosed in one of the 
//  neighbor IBDs (chr level) or a new is introduced from a border) 
// -------------------------------------------------------------------


int IBD_MCMC::make_remove_seminested_move(int max_len){

  int accept;

  // pick chr
  int sug_chr = randint(num_chrs-1);
  
  // pick IBD
  int sug_locus = randint(num_snps-1);
  int left,right; 
  int len = find1chrIBDhorizontal(sug_chr,sug_locus,&left,&right);
  
  // - check if its legal otherwise reject entire move
  if(len>max_len or left==0 or right==(num_snps-1)){
    accept = 0;
    return accept;
  }
  
  if((cur_zs->matrix[(left-1)][sug_chr]==cur_zs->matrix[(right+1)][sug_chr])){
    accept = 0;
    return accept;
  }
   
  // pick side
  int s = randint(1);
  int neighbor_IBD;
  if(s==0){
    neighbor_IBD = cur_zs->matrix[(left-1)][sug_chr];
  }
  else{
    neighbor_IBD = cur_zs->matrix[(right+1)][sug_chr];
  }

  for(int i=left;i<=right;i++){
    sug_zs->matrix[i][sug_chr] = neighbor_IBD;
  }

  // Evaluate it  
  iArray* borders = find_borders(cur_zs,sug_chr); // can be done faster!!
  int num_borders = borders->array[0];
  double a_addent = log(num_snps)-log((num_borders-1)*len*max_len*(k-1));
  accept = try_1chr_zregion_sug(left,right,sug_chr,a_addent);
  killArray(borders);
  return accept;

}




int IBD_MCMC::make_insert_seminested_move(int max_len){
 
  int accept;

  // Make proposal 
 
  // - pick chr
  int sug_chr = randint(num_chrs-1);
    
  // - pick IBD border (if any)
  iArray* borders = find_borders(cur_zs,sug_chr);
  int num_borders = borders->array[0];  
  if(num_borders==0){
    killArray(borders);
    accept = 0;
    return accept;
  }
  int sug_border = randint(1,num_borders);
  
  // - pick side
  int s = randint(1);
  
  // - pick IBD len
  int sug_len = randint(1,max_len);
  
  // - find left and right of new IBD
  int left,right;
  if(s==0){
    right = borders->array[sug_border]-1;
    left = right-sug_len+1;
  }
  else{
    left = borders->array[sug_border];
    right = left+sug_len-1;
  }
    
  // - reject if left or right is out of matrix
  if(left<=0){
    killArray(borders);
    accept = 0;
    return accept;
  }
  
  if(right>=(num_snps-1)){
    killArray(borders);
    accept = 0;
    return accept;
  }

  // - reject if new IBD not only in one IBD
  bool left_ok = 0;
  bool right_ok = 0;
  if(sug_border==1){
    left_ok = 1;
  }
  else{
    if(borders->array[sug_border-1]<left){
      left_ok = 1;
    }
  }
  if(sug_border==num_borders){
    right_ok = 1; // xxx
  }
  else{
    if(borders->array[sug_border+1]>(right+1)){
      right_ok = 1;
    }
  }

  // - pick new IBD for region
  int new_IBD = randint(k-2);
  int IBDl=cur_zs->matrix[left-1][sug_chr];
  int IBDr=cur_zs->matrix[right+1][sug_chr];
  if(new_IBD==IBDl){
    new_IBD=k-1;
  }
  if(new_IBD==IBDr){
    new_IBD=k;
  }
  
  for(int i=left;i<=right;i++){
    sug_zs->matrix[i][sug_chr] = new_IBD;
  }
   
  // Evaluate it  
  double a_addent = log(num_borders*sug_len*max_len*(k-1))-log(num_snps);
  accept = try_1chr_zregion_sug(left,right,sug_chr,a_addent);
  killArray(borders);
  return accept;

}






// A move that copies from one chromosome to others
// -------------------------------------------------------------------


int IBD_MCMC::find_num_ID_chrs(int chr,int reg_start,
			       int reg_end,iArray *chr_set){
  
  int pot_num_ID_chrs = chr_set->x;
  bool is_ID;
  int num_ID_chrs = 0;
  
  int cur_pot_chr;
  for(int c=0;c<pot_num_ID_chrs;c++){
    cur_pot_chr = chr_set->array[c];
    if(cur_pot_chr==chr){
      continue;
    }
    else{
      is_ID=true;
      for(int l=reg_start;l<=reg_end;l++){
	if(!(cur_zs->matrix[l][chr]==cur_zs->matrix[l][cur_pot_chr])){
	  is_ID = false;
	}
      }
      if(is_ID){
	num_ID_chrs++;
      }
    }
  }

  return num_ID_chrs;

}


int IBD_MCMC::find_num_ID_chrs_comp(int chr,int reg_start,
				    int reg_end,
				    iArray *comp_chr_set){
  
  bool is_ID;
  int num_ID_chrs = 0;
  int size_comp_set = comp_chr_set->x;
  bool skip;

  for(int c=0;c<num_chrs;c++){
    
    // skip if chr or in comp set
    if(c==chr){
      skip = true;
    }
    else{
      skip = false;
      for(int cc=0;cc<size_comp_set;cc++){
	if(comp_chr_set->array[cc]==c){
	  skip = true;
	}
      }
    }
    if(skip){
      continue;
    }
    // else check if ID with chr
    else{
      is_ID = true;
      for(int l=reg_start;l<=reg_end;l++){
	if(!(cur_zs->matrix[l][chr]==cur_zs->matrix[l][c])){
	  is_ID = false;
	}
      }
      if(is_ID){
	num_ID_chrs++;
      }
    }
  }
  return num_ID_chrs;
}




int IBD_MCMC::make_copy_move(int max_len){
 
  int accept;

  // Make proposal

  // - pick region length
  int sug_len = randint(1,max_len);

  // - pick start locus
  int sug_locus = randint(num_snps-sug_len);
  
  // - pick chr to copy from
  int chr_to_copy_from = randint(num_chrs-1);

  // - pick number of chrs to copy to
  int num_chrs_to_change = randint(1,num_chrs-1);

  // - pick chrs to copy to
  iArray *chrs_to_change = pick_numbers(num_chrs_to_change,num_chrs-1);

  for(int i=0;i<num_chrs_to_change;i++){
    if(chrs_to_change->array[i]==chr_to_copy_from){
      chrs_to_change->array[i] = (num_chrs-1);
      break;
    }
  }

  // - calculate region borders  
  int left = sug_locus; 
  int right = sug_locus+sug_len-1;

  // copy 
  int orig,cc;
  for(int i=left;i<=right;i++){
    orig = cur_zs->matrix[i][chr_to_copy_from];
    for(int c=0;c<num_chrs_to_change;c++){
      cc = chrs_to_change->array[c];
      sug_zs->matrix[i][cc] = orig;
    }
  }
  

  // Evaluate it  

  // - find out how many other chrs are ID to the 
  //   orig chr among the remaining chrs
  int num_ID_alt_orig_chrs = find_num_ID_chrs_comp(chr_to_copy_from,left,
						    right,chrs_to_change);
  // - calc a_addent
  double a_addent = (log(num_chrs-num_chrs_to_change)-
 		     log(num_ID_alt_orig_chrs+1)-
		     log(pow((double)(1+k),(sug_len*num_chrs_to_change))));
  
  accept = try_zregion_sug(left,right,chrs_to_change,a_addent);
  killArray(chrs_to_change);
  return accept;

}



int IBD_MCMC::make_undo_copy_move(int max_len){
 
  int accept;

  // Make proposal
  
  // - pick region length
  int sug_len = randint(1,max_len);

  // - pick start locus
  int sug_locus = randint(num_snps-sug_len);
  
  // - pick number of chrs to change
  int num_chrs_to_change = randint(1,num_chrs-1);
  
  // - pick chrs to change
  iArray *chrs_to_change = pick_numbers(num_chrs_to_change,num_chrs);
  
  // - calc region borders
  int left = sug_locus; 
  int right = sug_locus+sug_len-1;

  // - reject if change is legal
  int num_ID_in_chosen = (1+find_num_ID_chrs(chrs_to_change->array[0],
					     left,right,chrs_to_change));
  
  if(!(num_ID_in_chosen==num_chrs_to_change)){
    accept = 0;
    killArray(chrs_to_change);
    return accept;
  }

  // - change chrs
  int cc;
  for(int i=left;i<=right;i++){
    for(int c=0;c<num_chrs_to_change;c++){
      cc = chrs_to_change->array[c];
      sug_zs->matrix[i][cc] = randint(k);
    }
  }

  // Evaluate it    
  // - calc a_addent
  int num_ID_with_chosen = (find_num_ID_chrs_comp(chrs_to_change->array[0],
						  left,right,chrs_to_change));
  double a_addent = (log(num_ID_with_chosen)+
		     log(pow((double)(1+k),sug_len*num_chrs_to_change))-
 		     log(num_chrs-num_chrs_to_change));
  
  accept = try_zregion_sug(left,right,chrs_to_change,a_addent);
  killArray(chrs_to_change);
  
  return accept;
}




// A move that changes the state of an IBD bliock on chr level
// -------------------------------------------------------------------


int IBD_MCMC::make_1chr_IBD_block_state_change_move(int max_len){
  
  int accept;

  // Make proposal
  // - pick chromosome uniformly
  int sug_chr = randint(num_chrs-1);
  
  // - pick IBD uniformly
  // -- find borders
  iArray *borders = find_borders(cur_zs,sug_chr);
  int num_borders = borders->array[0];
  
  // -- pick IBD block and find its start and stop
  int block_start,block_end;
  int sug_block = randint(num_borders);

  if(sug_block==0){
    block_start = 0;
  }
  else{
    block_start = borders->array[sug_block];
  }
  if(sug_block==num_borders){
    block_end = num_snps-1;
  }
  else{    
    block_end = borders->array[sug_block+1]-1;
  }

  // -- check length of block and reject if max_length is exceeded
  int block_len = block_end-block_start+1;
  if(block_len>max_len){
    accept = 0;
    killArray(borders);
    return accept;
  }

  // - Pick new state
  // -- find illegal IBD states (current state and states of neighbor blocks)
  int illegal_states[3];
  illegal_states[0] = cur_zs->matrix[block_start][sug_chr];
  int num_illegal_states = 1;
 
  if(!(sug_block==0)){
    illegal_states[num_illegal_states] = cur_zs->matrix[block_start-1][sug_chr];
    num_illegal_states++;
  }
  if(!(sug_block==num_borders)){
    int other_neighbor_state = cur_zs->matrix[block_end+1][sug_chr];
    if(!(illegal_states[(num_illegal_states-1)]==other_neighbor_state)){
      illegal_states[num_illegal_states] = cur_zs->matrix[block_end+1][sug_chr];
      num_illegal_states++;
    }
  }
  
  if(num_illegal_states>=k){
    accept = 0;
    killArray(borders);
    return accept;
  }


  int sug_state = pick_a_legal_number(k,illegal_states,num_illegal_states);
  for(int i=0;i<block_len;i++){
    sug_zs->matrix[block_start+i][sug_chr] = sug_state;
  }  

  // Evaluate proposal
  accept = try_1chr_zregion_sug(block_start,block_end,sug_chr);
  killArray(borders);
  return accept;

}  



// A meta move that offers of doing making any of the other moves
// -------------------------------------------------------------------


int IBD_MCMC::make_move(int move_type,move_pars *pars){

  switch(move_type)
    {
      
    case 0:
      // full lambda move
      return make_lambda_move();
      
    case 1:
      // full rho move
      return make_rho_move();
      
    case 2:
      // window lambda move
      return make_window_lambda_move(pars->half_window_size_lam);
      
    case 3:
      // window rho move
      return make_window_rho_move(pars->half_window_size_rho);

    case 4:
      // one chromosome region z move
      return make_1chr_region_z_move(pars->max_len_5);

    case 5:
      // single z move
      return make_single_z_move();

    case 6:
      // one chromosome border move
      return make_1chr_border_z_move(pars->max_len_6);
    
    case 7:
      // multi chromosome region z move
      return make_multichr_region_z_move(pars->max_len_7);
    
    case 8:
     // IBD expansion/reduction move
      {
	int r = randint(1);
	int acc;
	if(r==0){
	  acc = make_IBD_expansion_move(pars->max_len_8);
	}
	else{
	  acc = make_IBD_reduction_move(pars->max_len_8);
	}
      return acc;
      }
    case 9:
      // nested IBD removal/insertion
      {
	int r = randint(1);
	int acc;
	if(r==0){
	  acc = make_remove_nested_move(pars->max_len_9);
	}
	else{
	acc = make_insert_nested_move(pars->max_len_9);
	}
	return acc;
      }
    case 10:
      // nested IBD removal/insertion
      {
	int r = randint(1);
	int acc;
	if(r==0){
	  acc = make_remove_seminested_move(pars->max_len_10);
	}
	else{
	  acc = make_insert_seminested_move(pars->max_len_10);
	}
	return acc;
      }
    case 11:
      // copy between chromosomes
      {
	int r = randint(1);
	int acc;
	if(r==0){
	  acc = make_copy_move(pars->max_len_11);
	}
	else{
	  acc = make_undo_copy_move(pars->max_len_11);
	}
	return acc;
      }
    case 12:
      // copy between chromosomes
      {
	return make_1chr_IBD_block_state_change_move(pars->max_len_12);
      }
    default:
      return 0;

    }
}



void print_time_and_accepts(time_t init_seconds,iArray *num_accepts,bool short_version=true){

  time_t seconds = time (NULL);
  printf("\t%ld",seconds-init_seconds);
  if(!short_version){
  int num_move_types = num_accepts->x;
  for(int i=0; i<(num_move_types);i++){
    printf("\t%d",num_accepts->array[i]);
  }
  }
  printf("\n");
}



// -------------------------------------------------------------------
// Class for doing MCMC with a fixed region
// -------------------------------------------------------------------


class IBD_MCMC_FIX : public IBD_MCMC{

public:

  // Functions
  
  // Constructor 
  IBD_MCMC_FIX(iArray *fixed_chrs,
	       int fixed_region_start,
	       int fixed_region_end,
	       int init_k,iMatrix *init_genos,
	       dArray *init_snp_dists,
	       dMatrix *init_frac_table,iMatrix* init_zs,
	       double init_lam,double init_rho,
	       double eps,double temp);

  
  // The functions that are different from the non-fix class
  virtual int try_zregion_sug(int start, int end, 
			      iArray *changed_chrs, 
			      double a_addent);

  virtual int try_1chr_zregion_sug(int start, int end, 
				   int chr, 
				   double a_addent);

  // The additional variables to those in the non-fix class 
  set<int> set_of_fixed_chrs; // The chromosomes with a fixed region
  int fixed_reg_start;        // The first fixed SNP
  int fixed_reg_end;          // The last fixed SNP
  
};



// -------------------------------------------------------------------
// Chain administration
// -------------------------------------------------------------------


// Initialization of chain (all vars and datastructures)
// -------------------------------------------------------------------

IBD_MCMC_FIX::IBD_MCMC_FIX(iArray *fixed_chrs,
			   int fixed_region_start,
			   int fixed_region_end,
			   int init_k,iMatrix *init_genos,
			   dArray *init_snp_dists,
			   dMatrix *init_frac_table,
			   iMatrix* init_zs,
			   double init_lam,double init_rho,
			   double eps,double temp=1)
  : IBD_MCMC(init_k,init_genos,init_snp_dists,init_frac_table,
	     init_zs,init_lam,init_rho,eps,temp){
  
  int set_size = fixed_chrs->x;
  set_of_fixed_chrs = set<int>(fixed_chrs->array,(fixed_chrs->array)+set_size);
  fixed_reg_start = fixed_region_start;
  fixed_reg_end = fixed_region_end;

}



// -------------------------------------------------------------------
// The help functions that is overridden in this class
// -------------------------------------------------------------------



// Evaluates proposal specified in sug_zs 
// (same consecutive region in multiple chrs)
int IBD_MCMC_FIX::try_zregion_sug(int start, int end,
				  iArray *changed_chrs, 
				  double a_addent=0.0){
  
  // test if region borders are valid
  if(start<0 or end>num_snps-1){
    printf("Region borders are not valid: ");
    printf("start is %d and end is %d\n",start,end);
    exit(EXIT_FAILURE);
  }
  
  
  // test if change is proposed to fixed zs 
  // if it is reject proposal
  // - if change is proposed to fixed region
  int accept;
  if(fixed_reg_start<=end and start<=fixed_reg_end){
    // - and  is proposed to a fixed chr
    int chr;
    set<int>::iterator it;
    
    for(int i=0;i<changed_chrs->x;i++){
      chr = changed_chrs->array[i];
      it = find(set_of_fixed_chrs.begin(), 
		set_of_fixed_chrs.end(), 
		chr);
      if (!(it == set_of_fixed_chrs.end())){
	// we reject proposal immediately
	accept = 0;
	return accept;
      }
    }
  }
  
  accept = IBD_MCMC::try_zregion_sug(start,end,changed_chrs,a_addent);
  return accept;
    
}


// Evaluates proposal specified in sug_zs 
// (consecutive region in one chr)
int IBD_MCMC_FIX::try_1chr_zregion_sug(int start, int end, int chr,
				       double a_addent=0.0){
  
  // stop program if region borders are invalid 
  if(start<0 or end>num_snps-1){
    printf("Region borders are not valid: ");
    printf("start is %d and end is %d\n",start,end);
    exit(EXIT_FAILURE);
  }
  
  // reject immediately if proposal changes anything fixed
  // - if change is in the fixed loci
  int accept;
  if(fixed_reg_start<=end and start<=fixed_reg_end){
    set<int>::iterator it = find(set_of_fixed_chrs.begin(), 
				 set_of_fixed_chrs.end(), 
				 chr);
    // - and change is made to a fixed chr
    if (!(it == set_of_fixed_chrs.end())){
      // we reject proposal immediately
      accept = 0;
      return accept;
    }
  }
  // if borders are valid and nothing fixed is changes 
  // we test the proposal as usual
  accept = IBD_MCMC::try_1chr_zregion_sug(start,end,chr,a_addent); 
  return accept;

}








// The MCMC algorithm
// ---------------------------------------------------------------------

void MCMC(int k,iMatrix *genos,dArray *snp_dists,
	  dMatrix *frac_table,double eps,int thinning,
	  int num_its,iMatrix* init_zs,double init_lam,
	  double init_rho,iArray *num_moves_in_it,
	  int seed, move_pars* pars){

  // Set seed 
  initrand(seed);

  // Init MCMC object
  IBD_MCMC mcmc(k,genos,snp_dists,frac_table,init_zs,
		init_lam,init_rho,eps);

  // Init containers for time and accept statistics
  int accept,num_moves;
  int num_move_types = num_moves_in_it->x;
  iArray *num_accepts = allocIntArray(num_move_types); 
  time_t init_seconds = time (NULL);
 
  // Print out initial state of MCMC object
  mcmc.print_cur_pars(0);
  print_time_and_accepts(init_seconds,num_accepts);
  mcmc.print_cur_IBD_states();
    
  // Run num_its iterations of MCMC
  for(int i=1;i<=num_its;i++){

    
    // For each move type the corresponding number of moves are performed
    for(int move_type=0; move_type<num_move_types; move_type++){
      num_moves = num_moves_in_it->array[move_type];
      for(int move=0;move<num_moves;move++){
	accept = mcmc.make_move(move_type,pars);
	num_accepts->array[move_type]+=accept;
      }  
    }

    // All relevant info is written to screen every "thinning" iteration
    if((i%thinning)==0){            
      mcmc.print_cur_pars(i);
      print_time_and_accepts(init_seconds,num_accepts);
      mcmc.print_cur_IBD_states();
      
      // reset number of accepts to zero
      for(int move_type=0;move_type<num_move_types;move_type++){
	num_accepts->array[move_type] = 0;     
      }
    }
  }
  // print last state
  //mcmc.print_cur_pars(num_its);
  //print_time_and_accepts(init_seconds,num_accepts);
  //mcmc.print_cur_IBD_states();
  killArray(num_accepts);
}




void MCMC_fixed(iArray *fixed_chrs,int fixed_region_start,
		int num_fixed,int k,iMatrix *genos,dArray *snp_dists,
		dMatrix *frac_table,double eps,int thinning,
		int num_its,iMatrix* init_zs,double init_lam,
		double init_rho,iArray *num_moves_in_it,
		int seed, move_pars* pars){

  // Set seed 
  initrand(seed);

  // Init MCMC fix object 
  IBD_MCMC_FIX mcmc(fixed_chrs,fixed_region_start,
		    fixed_region_start+num_fixed-1,
		    k,genos,snp_dists,frac_table,init_zs,
		    init_lam,init_rho,eps);

  // Init containers for time and accept statistics
  int accept,num_moves;
  int num_move_types = num_moves_in_it->x;
  iArray *num_accepts = allocIntArray(num_move_types); 
  time_t init_seconds = time (NULL);
 
  // Print out initial state of MCMC object
  mcmc.print_cur_pars(0);
  print_time_and_accepts(init_seconds,num_accepts);
  mcmc.print_cur_IBD_states();
    
  // Run num_its iterations of MCMC
  for(int i=1;i<=num_its;i++){

    
    // For each move type the corresponding number of moves are performed
    for(int move_type=0; move_type<num_move_types; move_type++){
      num_moves = num_moves_in_it->array[move_type];
      for(int move=0;move<num_moves;move++){
	accept = mcmc.make_move(move_type,pars);
	num_accepts->array[move_type]+=accept;
      }  
    }

    // All relevant info is written to screen every "thinning" iteration
    if((i%thinning)==0){            
      mcmc.print_cur_pars(i);
      print_time_and_accepts(init_seconds,num_accepts);
      mcmc.print_cur_IBD_states();
      
      // reset number of accepts to zero
      for(int move_type=0;move_type<num_move_types;move_type++){
	num_accepts->array[move_type] = 0;     
      }
    }
  }
  // print last state
  //mcmc.print_cur_pars(num_its);
  //print_time_and_accepts(init_seconds,num_accepts);
  //mcmc.print_cur_IBD_states();
  killArray(num_accepts);
}



