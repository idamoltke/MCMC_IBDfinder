/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// HMM Module:
// Implements functionality to work with an HMM that models
// IBD sets in SNPs from numerous individuals of unknown relation
//
// Implemented by Ida Moltke, fall 2008 - fall 2010
// -------------------------------------------------------------------


// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#include <iostream>
#include <cmath>
#include <fstream>
#ifndef _types_h
#define _types_h
#include "types.h"
#endif
#include "alloc.h"
#include "io.h"
using namespace std;


// -------------------------------------------------------------------
// Help functions
// -------------------------------------------------------------------


// Function that is used when running through all Yi values
// (returns bit number 'bit_number' (0 is the rightmost bit) in the 
//  binary representation of 'dec_num)
// -------------------------------------------------------------------

int get_bit_value(int dec_num, int bit_number){
  return (dec_num >> bit_number) & 1;
}


// Function that is used when running through all Yi values
// (returns bit number 'bit_number' (0 is the rightmost bit) in the 
//  binary representation of 'dec_num)
// -------------------------------------------------------------------

dMatrix* make_error_prob_table(double eps){

  dMatrix *error_prob_table = allocDoubleMatrix(3,4);    
  error_prob_table->matrix[0][0] = pow(1-eps,2);
  error_prob_table->matrix[0][1] = (eps)*(1-eps);
  error_prob_table->matrix[0][2] = (eps)*(1-eps);
  error_prob_table->matrix[0][3] =  pow(eps,2);
  
  error_prob_table->matrix[1][0] = 2*(eps)*(1-eps);  
  error_prob_table->matrix[1][1] = pow(1-eps,2)+pow(eps,2);
  error_prob_table->matrix[1][2] = pow(1-eps,2)+pow(eps,2);
  error_prob_table->matrix[1][3] = 2*(eps)*(1-eps);  

  error_prob_table->matrix[2][0] =  pow(eps,2);
  error_prob_table->matrix[2][1] = (eps)*(1-eps); 
  error_prob_table->matrix[2][2] = (eps)*(1-eps); 
  error_prob_table->matrix[2][3] =  pow(1-eps,2);
      
  return error_prob_table;
}



// -------------------------------------------------------------------
// Functions for calculating emission probabilities
// -------------------------------------------------------------------


// Emission for a specific chromosome at a specific locus
// -------------------------------------------------------------------

double e_single(int i,bool in_unique_ibd,int x_single_obs,
		int x_single_real,dMatrix *frac_table){
  
  // if not in an IBD set
  if(in_unique_ibd){
    return frac_table->matrix[i][x_single_obs]; 
  }
  // if in IBD
  else{
    if(x_single_obs==x_single_real){
      return 1;
    }
    else{
      return 0;
    }
  }
}



// Emission table value for a specific geno/IBD combination (for 
// both chromosomes) at a specific locus (Errors are accepted)
// -------------------------------------------------------------------

double calc_e_table_val(int locus,int x_obs,
			bool x_unique1,int x_single_real1,
			bool x_unique2,int x_single_real2,
			dMatrix *frac_table,
			dMatrix *error_table){
  
  double e_a1 = e_single(locus,x_unique1,0,x_single_real1,frac_table);
  double e_a2 = e_single(locus,x_unique2,0,x_single_real2,frac_table);
  double e_A1 = e_single(locus,x_unique1,1,x_single_real1,frac_table);
  double e_A2 = e_single(locus,x_unique2,1,x_single_real2,frac_table);
  
  double ret_e;
  
  ret_e = error_table->matrix[x_obs][0]*e_a1*e_a2; 
  ret_e+= error_table->matrix[x_obs][1]*e_a1*e_A2; 
  ret_e+= error_table->matrix[x_obs][2]*e_A1*e_a2; 
  ret_e+= error_table->matrix[x_obs][3]*e_A1*e_A2; 
  
  return ret_e;
  
}


// Function that makes a table with emission values for all genotype
// if both chromosomes are in none unique IBDs (locus independent)
// -------------------------------------------------------------------

dMatrix *make_e_table_no_u(dMatrix *error_table){
  
  // initialise lookup table
  dMatrix *lookup_table = allocDoubleMatrix(3,3);
  
  // copy relavant values from error_table
  for(int obs_geno=0;obs_geno<3;obs_geno++){
    for(int real_geno=0;real_geno<3;real_geno++){  
      if(real_geno!=2){
	lookup_table->matrix[obs_geno][real_geno]=error_table->matrix[obs_geno][real_geno];
      }else{
	// in error table the values that correspond to real_geno 2 cor are in col 3 
	lookup_table->matrix[obs_geno][real_geno]=error_table->matrix[obs_geno][3];
      }
    }
  }
  return lookup_table;
}


// Function that makes a table with emission values for all genos if 
// at least one chromosomes are in none unique IBDs
// -------------------------------------------------------------------

dMatrix *make_e_table_with_u(int num_snps,dMatrix *frac_table,dMatrix *error_table){
  
  // initialise lookup table
  dMatrix *lookup_table = allocDoubleMatrix(num_snps,9);
  int emission_type;
  // for each locus a table is calculate
   for(int locus=0;locus<num_snps;locus++){
     // both chrs alone in an IBD 
     emission_type = 0;
     for(int x_obs=0;x_obs<=2;x_obs++){
       lookup_table->matrix[locus][emission_type] = calc_e_table_val(locus,x_obs,
								     true,-1,
								     true,-1,
								     frac_table,
								     error_table);
       emission_type++;
     }
     // one chr is alone in an IBD 
     for(int x_single_real1=0;x_single_real1<2;x_single_real1++){
       for(int x_obs=0;x_obs<=2;x_obs++){
	 lookup_table->matrix[locus][emission_type] = calc_e_table_val(locus,x_obs,
								       false,x_single_real1,
								       true,-1, 
								       frac_table,
								       error_table);
 	emission_type++;
	
       }
     }
   }
   return lookup_table;

}


// The emission probability for (a piece of) a given state matrix 
// and a given geno matrix
// -------------------------------------------------------------------

double calc_e(int first_locus,int last_locus,iMatrix *genos,
	      iMatrix *zs,int k,
	      int num_inds,dMatrix *frac_table,dArray *log_es,
	      iArray *yi, dMatrix *e_table_has_unique,
	      dMatrix *e_table_has_no_unique){


  // Declare variable necessary for the calcs
  int num_chrs = num_inds*2;
  int num_yis,yi_dec,yizj,num_relevant_IBD_sets,last;
  int zs1,zs2,geno,real_allele_chr1,real_allele_chr2;
  double P_cur_yi,e_cur_locus_cur_yi,e_cur_locus_cur_ind_cur_yi,e_cur_pos,log_e_cur_pos;
  bool chr1_unique,chr2_unique;

  iArray *IBD_set_counts  = allocIntArray(k+1);
  iArray *relevant_IBD_sets  = allocIntArray(k+1);    
  
  // For each locus the emission is calc and is added to the total log(e)
  double log_e_total = 0;
  for(int locus=first_locus;locus<=last_locus;locus++){

    // find relevant yis in locus
    for(int s=0; s<(k+1);s++){
       IBD_set_counts->array[s]=0; 
       relevant_IBD_sets->array[s]=0; 
     }    

     for(int chr=0;chr<num_chrs;chr++){
       IBD_set_counts->array[(zs->matrix[locus][chr])] += 1;
     }
     
     last = 0;
     for(int s=1; s<k+1; s++){
       if (IBD_set_counts->array[s] > 1){
	 relevant_IBD_sets->array[last] = s;
	 last+=1;
       }
     }

     relevant_IBD_sets->array[last] = -1;
     relevant_IBD_sets->array[k] = last;
    
     // find emission probability as the sum of emission for all possible yi values
     e_cur_pos = 0;
     num_relevant_IBD_sets = relevant_IBD_sets->array[k];
     num_yis = (int) pow((float) 2,num_relevant_IBD_sets);
    
     for(yi_dec=0;yi_dec<num_yis;yi_dec++){

       // for each addend find yi and P(yi)
       P_cur_yi = 1;
       
       for(int j=0; j<num_relevant_IBD_sets;j++){
	 yizj = (int) get_bit_value(yi_dec,j);
	 int j_index = relevant_IBD_sets->array[j];
	 yi->array[j_index] = yizj;
	 P_cur_yi = P_cur_yi*frac_table->matrix[locus][yizj]; 
       }
       
       // calc emission given yi
       e_cur_locus_cur_yi = P_cur_yi;
       int chr = 0;
       
       
       // multiply emission of all individuals 
       for(int ind=0; ind<num_inds; ind++,chr+=2){
	 // lookup emission of ind
	 // - if either chrs are in a unique IBD set we look it up in
	 //   'e_table_has_unique' with keys according to locus, observed 
	 //   geno and allele type of non-unique (if any)
	 zs1 = zs->matrix[locus][chr];
	 zs2 = zs->matrix[locus][chr+1];
	 chr1_unique = (zs1==0 || IBD_set_counts->array[zs1]==1);
	 chr2_unique = (zs2==0 || IBD_set_counts->array[zs2]==1);
	 geno = genos->matrix[locus][ind];
	 if(chr1_unique){
	   if(chr2_unique){
	     e_cur_locus_cur_ind_cur_yi = e_table_has_unique->matrix[locus][geno];	    
	   }else{
	     real_allele_chr2 = yi->array[zs2];
	     if(real_allele_chr2==0){
	       e_cur_locus_cur_ind_cur_yi = e_table_has_unique->matrix[locus][geno+3];	    
	     }else{
	       e_cur_locus_cur_ind_cur_yi = e_table_has_unique->matrix[locus][geno+6];	    
	     }
	   }
	 }else{
	   real_allele_chr1 = yi->array[zs1];
	   if(chr2_unique){
	     if(real_allele_chr1==0){
	       e_cur_locus_cur_ind_cur_yi = e_table_has_unique->matrix[locus][geno+3];	    
	     }else{
	       e_cur_locus_cur_ind_cur_yi = e_table_has_unique->matrix[locus][geno+6];	    
	     }
	   }else{
	     // - if none of the chrs are in a unique IBD set we look it up in
	     //   'e_table_has_no_unique' with keys according to observed geno and
	     //    allele types of the two chrs
	     real_allele_chr2 = yi->array[zs2];
	     e_cur_locus_cur_ind_cur_yi = e_table_has_no_unique->matrix[geno][real_allele_chr1+real_allele_chr2];	    
	   }
	 }
	 e_cur_locus_cur_yi = e_cur_locus_cur_yi*e_cur_locus_cur_ind_cur_yi;   
       }
       e_cur_pos += e_cur_locus_cur_yi; 
     }
     
    // If one factor is 0 the entire emission is 0
    if(e_cur_pos==0){
      printf("Warning: emission of 0 is returned in locus %d\n",locus);   
      //return NULL;
      throw 1;
    }
    else{
      log_e_cur_pos = log(e_cur_pos);
      log_e_total +=  log_e_cur_pos;
      log_es->array[locus] = log_e_cur_pos;
    }
  }  
  
  killArray(IBD_set_counts);
  killArray(relevant_IBD_sets);

  return log_e_total;
}




//--------------------------------------------------------------------
// Functions for calculating transition probabilities
//--------------------------------------------------------------------


// The stationary probability for a given state
//--------------------------------------------------------------------

double Q(int z,double lam,double rho,int k){
  if(z==0){
    return rho/(lam+rho); 
  }
  else{
    return lam/(k*(lam+rho));
  }
}


// The transition probability for a given pair of states
//--------------------------------------------------------------------

double q(int z1,int z2,double t,double lam,double rho,int k){
  
  double denom_factor = lam+rho;
  
  if(z1==0){
    double enum_term = lam*exp(-t*(lam+rho));
    if(z2==0){
      return (enum_term+rho)/denom_factor;
    }
    else{
      return (-enum_term+lam)/(denom_factor*k);
    }
  }
  else{
    if(z2==0){
      return (rho-rho*exp(-t*(lam+rho)))/denom_factor;
    }
    else{
      double enum_term1 = exp(-t*rho);
      double enum_term2 = exp(-t*lam);
      if(z1==z2){
	return (enum_term1*((-1+k)*lam+(enum_term2-1+k)*rho)+lam)/(k*denom_factor);
      }	
      else{
	return (enum_term1*((-1)*lam+(enum_term2-1)*rho)+lam)/(k*denom_factor);
      }
    }
  }
}




// The transitions probability for (a piece of) a given state matrix
//--------------------------------------------------------------------

double calc_t(int first_locus,int last_locus,dArray *t_diffs,iMatrix *zs,int k,
	      double lam,double rho,int num_inds,dArray *log_ts){

  double t_cur_locus = 1.0;
  double log_t_cur_locus = 0.0;
  double log_t_total = 0.0;
  int num_chrs = num_inds*2;

  if(first_locus==0){
    // first SNP
    for(int chr=0; chr<num_chrs; chr++){
      t_cur_locus *= Q(zs->matrix[0][chr],lam,rho,k); 
    }      
 
    log_t_cur_locus = log(t_cur_locus);
    log_t_total = log_t_cur_locus;
    log_ts->array[0] = log_t_cur_locus;
    first_locus = 1;
  } 


  // for each of the (rest of the) SNPs
  for(int locus = first_locus;locus<=last_locus;locus++){
    t_cur_locus = 1;
    
    for(int chr=0;chr<num_chrs;chr++){
      t_cur_locus *= q(zs->matrix[locus-1][chr],zs->matrix[locus][chr],
		       t_diffs->array[locus],lam,rho,k);
    }
    // If one factor is 0 the entire emission is 0
    if(t_cur_locus==0){
      printf("Warning: transition prob to locus %d is zero\n",locus);   
      //return NULL;
      throw 1;
    }
    else{
      log_t_cur_locus = log(t_cur_locus);
      log_t_total += log_t_cur_locus;
      log_ts->array[locus] = log_t_cur_locus;
    }
  }

  return log_t_total;
}
  



// The transitions probability for (a piece of) a given chromosome
//--------------------------------------------------------------------


double calc_t_1chr(int first_locus,int last_locus,dArray *t_diffs,iMatrix *zs,int k,
	      double lam,double rho,int num_inds,dArray *log_ts,int chr){

  double t_cur_locus = 1.0;
  double log_t_cur_locus = 0.0;
  double log_t_total = 0.0;
 
  if(first_locus==0){
    // first SNP
    t_cur_locus = Q(zs->matrix[0][chr],lam,rho,k);  
  
    // If one factor is 0 the entire emission is 0
    if(t_cur_locus==0){
      printf("Warning: stationary prob to locus 0 is zero\n");   
      //return NULL;
      throw 1;
    }
    else{
      log_t_cur_locus = log(t_cur_locus);
      log_t_total =  log_t_cur_locus;
      log_ts->array[0] = log_t_cur_locus;
      first_locus = 1;
    } 
  }
  

  // for each of the (rest of the) SNPs
  for(int locus = first_locus;locus<=last_locus;locus++){
    t_cur_locus = q(zs->matrix[locus-1][chr],zs->matrix[locus][chr],
		       t_diffs->array[locus],lam,rho,k);
    
    // If one factor is 0 the entire emission is 0
    if(t_cur_locus==0){
      printf("Warning: transition prob to locus %d is zero\n",locus);   
      //return NULL;
      throw 1;
    }
    else{
      log_t_cur_locus = log(t_cur_locus);
      log_t_total += log_t_cur_locus;
      log_ts->array[locus] = log_t_cur_locus;
    }
  }

  return log_t_total;

}
  







