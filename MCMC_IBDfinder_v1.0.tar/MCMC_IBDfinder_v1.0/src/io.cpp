/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// IO module header:
// Implements functionality to read in and write out data
//
// Implemented by Ida Moltke, fall 2007 - fall 2010 
// (based on code by Thorfinn Sand Korneliussen)
// -------------------------------------------------------------------


// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#include <string.h>
#include <cstdlib>
#include "io.h"
#include <fstream>
#include "alloc.h"
#ifndef _types_h
#define _types_h
#include "types.h"
#endif

using namespace std;


// -------------------------------------------------------------------
// Functions for reading data in 
// -------------------------------------------------------------------

iMatrix *get_i_data(const char *pName){

  int c=0;
  int r=0;
  iMatrix *data;
  
  const int SIZE=40000;
  char buffer[SIZE];
  char *buffer_ar;
  ifstream pFile (pName);
  
  if(!pFile){
    // file doesn't exist
    exit(0);
  }

  int tmp=0;
  while(!pFile.eof()){
    tmp++;
    pFile.getline(buffer,SIZE);
    
    /*
      Removing the pathological cases of 
      new line sprees.
      And the equally annoying extra whitespaces
    */
    if (strlen(buffer)>2){
      
      char *tokenized=buffer;
      buffer_ar = strsep(&tokenized,"\t");
      if (c==0)
	while (buffer_ar!=NULL ){
	  r++;
	  buffer_ar = strsep(&tokenized, "\t");
	  if (buffer_ar!=NULL)
	    if(!strcmp(buffer_ar,"")){
	      break;
	    }
	} 
      c++;
    }

  }
  pFile.close();

  data = allocIntMatrix(c,r);
  int inDataSet;
  ifstream pFile1 (pName);
  
  for (int i=0;i<c;i++) {
    pFile1.getline(buffer,SIZE);
    char *tokenized=buffer;
    //loop throug each colomn
    for(int s=0;s<r;s++){
      buffer_ar = strsep(&tokenized,"\t");
      inDataSet = atoi(buffer_ar);
      data->matrix[i][s]=inDataSet;
    }
  }
  pFile1.close();
  return data;
  
}


dMatrix *get_d_data(const char *pName){

  int c=0;
  int r=0;
  dMatrix *data;
  
  const int SIZE=40000;
  char buffer[SIZE];
  char *buffer_ar;
  ifstream pFile (pName);
  
  if(!pFile){
    // file doesn't exist
    exit(0);
  }

  int tmp=0;
  while(!pFile.eof()){

    tmp++;
    pFile.getline(buffer,SIZE);
    
    /*
      Removing the pathological cases of 
      new line sprees.
      And the equally annoying extra whitespaces
    */
    if (strlen(buffer)>2){
      
      char *tokenized=buffer;
      buffer_ar = strsep(&tokenized,"\t");
      if (c==0)
	while (buffer_ar!=NULL ){
	  r++;
	  buffer_ar = strsep(&tokenized, "\t");
	  if (buffer_ar!=NULL)
	    if(!strcmp(buffer_ar,"")){
	      break;
	    }
	} 
      c++;
    }
 
  }
  pFile.close();
  data = allocDoubleMatrix(c,r);
  double inDataSet;
  ifstream pFile1 (pName);
  


  for (int i=0;i<c;i++) {
    pFile1.getline(buffer,SIZE);
    char *tokenized=buffer;
    //loop throug each colomn
    for(int s=0;s<r;s++){
      buffer_ar = strsep(&tokenized,"\t");
      inDataSet = atof(buffer_ar);
      data->matrix[i][s]=inDataSet;
    }
  }

  pFile1.close();

  return data;
  
}



// -------------------------------------------------------------------
// Functions for writing out data 
// -------------------------------------------------------------------


void print_array(iArray *a){
  for(int i=0;i<a->x;i++)
    //    printf("i=%d:%d\t",i,a->array[i]);
    printf("%d\t",a->array[i]);
  printf("\n");
}

void print_array(dArray *a){
  for(int i=0;i<a->x;i++)
    printf("i=%d:%f\t",i,a->array[i]);
  printf("\n");
}

void print_matrix(iMatrix *m){
  for(int r=0;r<(m->x);r++){
    for(int c=0;c<(m->y);c++){
	printf("row=%d,col=%d:%d\t",r,c,m->matrix[r][c]);
      }
        printf("\n");
  }
}

void print_matrix(dMatrix *m){
  for(int r=0;r<(m->x);r++){
    for(int c=0;c<(m->y);c++){
	printf("row=%d,col=%d:%f\t",r,c,m->matrix[r][c]);
      }
        printf("\n");
  }
}


void print_matrix(iMatrix *m,int c){
  for(int r=0;r<(m->x);r++){
    printf("%d\t",m->matrix[r][c]);
      }
    printf("\n");
}

void print_matrix(dMatrix *m,int c){
  for(int r=0;r<(m->x);r++){
    printf("%f\t",m->matrix[r][c]);
  }
  printf("\n");
}



void print_matrix_tabsep(dMatrix *m){
for(int c=0;c<(m->y);c+=2){
  printf("z ");
  for(int r=0;r<(m->x);r++){
      printf("%f\t",m->matrix[r][c]);
      printf("%f\t",m->matrix[r][c+1]);
    }
    printf("\n");
  }
}


void print_matrix_tabsep(iMatrix *m){
for(int c=0;c<(m->y);c+=2){
  printf("z ");
  for(int r=0;r<(m->x);r++){
      printf("%d\t",m->matrix[r][c]);
      printf("%d\t",m->matrix[r][c+1]);
    }
    printf("\n");
  }
}



