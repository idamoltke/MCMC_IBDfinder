/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// IO module header:
// Defines the interface for reading in and writing out data
//
// Implemented by Ida Moltke, fall 2007 - fall 2010 
// (based on code by Thorfinn Sand Korneliussen)
// -------------------------------------------------------------------

// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#ifndef _types_h
#define _types_h
#include "types.h"
#endif


// -------------------------------------------------------------------
// Declaration of functions for reading data in 
// -------------------------------------------------------------------

iMatrix *get_i_data(const char *pName);
dMatrix *get_d_data(const char *pName);


// -------------------------------------------------------------------
// Declaration of functions for writing out data 
// -------------------------------------------------------------------

void print_array(iArray *a);
void print_array(dArray *a);
void print_matrix(iMatrix *m);
void print_matrix(dMatrix *m);
void print_matrix(iMatrix *m,int c);
void print_matrix(dMatrix *m,int c);
void print_matrix_tabsep(iMatrix *m);
void print_matrix_tabsep(dMatrix *m);

