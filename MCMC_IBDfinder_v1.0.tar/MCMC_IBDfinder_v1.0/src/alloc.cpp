/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// Allocation module: 
// Implements functionality for allocating and deallocating the 
// different types used in the program
//
// Implemented by Ida Moltke, fall 2007 
// (based on some code by Thorfinn Sand Korneliussen)
// -------------------------------------------------------------------


// --------------------------------------------------- 
// Includes
// --------------------------------------------------- 

#include <iostream>
#include "alloc.h"
#ifndef _types_h
#define _types_h
#include "types.h"
#endif




// --------------------------------------------------- 
// Functions for allocating arrays and matrices
// --------------------------------------------------- 


iArray *allocIntArray(int i){
  int *tmp= new int[i];
  iArray *intArray = new iArray();
  for (int j=0;j<i;j++)
    tmp[j]=0;
  intArray->x=i;
  intArray->array=tmp;
  return intArray;
}


dArray *allocDoubleArray(int i){
  double *tmp= new double[i];
  dArray *doubleArray = new dArray();
  for (int j=0;j<i;j++)
    tmp[j]=0.0;
  doubleArray->x=i;
  doubleArray->array=tmp;
  return doubleArray;
}



iMatrix *allocIntMatrix(int x, int y){
  iMatrix *tmp = new iMatrix();
  int **ppi = new int*[x];
  int *curPtr = new int [x * y];
  
  for( int i = 0; i < x; ++i) {
      *(ppi + i) = curPtr;
      curPtr += y;
    }

  for (int i=0;i<x;i++)
    for(int n=0;n<y;n++)
      ppi[i][n]=0;
  tmp->matrix=ppi;
  tmp->x=x;
  tmp->y=y;
  return tmp;
}


dMatrix *allocDoubleMatrix(int x, int y){
  dMatrix *tmp = new dMatrix();
  double **ppi = new double*[x];
  double *curPtr = new double [x * y];
  
  for( int i = 0; i < x; ++i) {
      *(ppi + i) = curPtr;
      curPtr += y;
    }
  for (int i=0;i<x;i++)
    for(int n=0;n<y;n++)
      ppi[i][n]=0;
  tmp->matrix=ppi;
  tmp->x=x;
  tmp->y=y;
  return tmp;
}



lInfo *allocLikeInfo(int num_snps){
  lInfo * linfo = new lInfo;
  linfo->log_t =-1;
  linfo->log_e =-1;
  linfo->log_ts = allocDoubleArray(num_snps);
  linfo->tmp_log_ts = allocDoubleArray(num_snps);
  linfo->tmp2_log_ts = allocDoubleArray(num_snps);
  linfo->log_es = allocDoubleArray(num_snps);
  linfo->tmp_log_es = allocDoubleArray(num_snps);
  return linfo;
}



// --------------------------------------------------- 
// Functions for rearranging arrays and matrices
// --------------------------------------------------- 


iMatrix* transpose_matrix(iMatrix *m, bool freeold){
  
  iMatrix *tm = allocIntMatrix(m->y,m->x);
  for(int r=0;r<m->x;r++){
    for(int c=0;c<m->y;c++){
      tm->matrix[c][r]=m->matrix[r][c];
    }
  }
 
  if(freeold){
    killMatrix(m);
  }

  return tm;
}


iMatrix* format_z_matrix(iMatrix *m, bool freeold){
 
  iMatrix *fm = allocIntMatrix((m->x*2),(m->y/2));
  for(int r=0;r<m->x;r++){
    for(int c=0;c<m->y;c++){
      fm->matrix[(r*2)+(c%2)][c/2]=m->matrix[r][c];
    }
  }
 
  if(freeold){
    killMatrix(m);
  }

  return fm;
}


iMatrix* limit_matrix(iMatrix *m, int firstindex, int lastindex, bool freeold){
  int numentries = lastindex-firstindex+1;
  iMatrix *lm = allocIntMatrix(m->x,numentries);
 
  for(int r=0;r<m->x;r++){
    for(int c=firstindex;c<=lastindex;c++){
      lm->matrix[r][c-firstindex]=m->matrix[r][c];
    }
  }
 
  if(freeold){
    killMatrix(m);
  }

  return lm;
}



dMatrix* limit_matrix(dMatrix *m, int firstindex, int lastindex, bool freeold){
  int numentries = lastindex-firstindex+1;
  dMatrix *lm = allocDoubleMatrix(m->x,numentries);
 
  for(int r=0;r<m->x;r++){
    for(int c=firstindex;c<=lastindex;c++){
      lm->matrix[r][c-firstindex]=m->matrix[r][c];
    }
  }
 
  if(freeold){
    killMatrix(m);
  }

  return lm;
}

  


// --------------------------------------------------- 
// Functions for deallocating arrays and matrices
// --------------------------------------------------- 


void killArray(iArray *var){
  if(var!=NULL){
  delete [] var->array;
  delete var;
  }
}



void killArray(dArray *var){
  if(var!=NULL){
    delete [] var->array;
    delete var;
  }
}



void killDoubleMatrix(double **var){
  if(var!=NULL){
    delete [] *var;
    delete [] var;
  }
}

void killIntMatrix(int **var){
  if(var!=NULL){
    delete [] *var;
    delete [] var;
  }
}


void killMatrix(dMatrix *var){
  if(var!=NULL){
    killDoubleMatrix(var->matrix);
    delete var;
  }
}


void killMatrix(iMatrix *var){
  if(var!=NULL){
    killIntMatrix(var->matrix);
    delete var;
  }
}


void killLikeInfo(lInfo *var){
  if(var!=NULL){
    killArray(var->log_ts);
    killArray(var->tmp_log_ts);
    killArray(var->tmp2_log_ts);
    killArray(var->log_es);
    killArray(var->tmp_log_es);
    delete var;
  }
}




