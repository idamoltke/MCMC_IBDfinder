/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// Random number module header:
// Declares functions to support random number sampling
// -------------------------------------------------------------------



// --------------------------------------------------- 
// Functions for sampling pseudo random numbers
// --------------------------------------------------- 

void initrand(int seed);
void endrand(); // so random numbers from python can be supported
int randint(int max); 
int randint(int min,int max); 
float randfloat(); 
double randdouble(); 
double randdouble(double from,double to); 
iArray *pick_numbers(int num2choose,int num2choosefrom);
int pick_a_legal_number(int max_num, int illegal_numbers[], int num_illegal_numbers);


// --------------------------------------------------- 
// Class to wrap random number generator
// --------------------------------------------------- 

class DiscreteGen{
  void operator=(const DiscreteGen&) {}     // only privat access
  double *p; int *ialt; int n; double *val;
  void Gen(int, double*);                   // called by constructors
  
public:
  DiscreteGen(int,double*);                 // constructor
  DiscreteGen(int,double*,double*);         // constructor
  ~DiscreteGen();                           // destructor
  double Next();                            // returns next random number
};

