/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// MCMC module header:
// Specifies interface for doing MCMC 
//
// Implemented by Ida Moltke, fall 2007 - fall 2010 
// -------------------------------------------------------------------


void MCMC(int k,iMatrix *genos,dArray *snp_dists,dMatrix *frac_table,
	  double eps,int thinning,int num_its,
	  iMatrix* init_zs,double init_lam,double init_rho,
	  iArray *num_moves_in_it,int seed, move_pars* pars);

void MCMC_fixed(iArray* fixed_chrs, int fixed_region_start,int num_fixed,
		int k,iMatrix *genos,dArray *snp_dists,dMatrix *frac_table,
		double eps,int thinning,int num_its,
		iMatrix* init_zs,double init_lam,double init_rho,
		iArray *num_moves_in_it,int seed, move_pars* pars);


