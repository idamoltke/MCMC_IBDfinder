/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// Allocation module header: 
// Defines the interface for allocating, 
// rearranging and deallocating the different types in the program
//
// Implemented by Ida Moltke, fall 2007 - fall 2010
// (based on code by Thorfinn Sand Korneliussen)
// -------------------------------------------------------------------


// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#ifndef _types_h
#define _types_h
#include "types.h"
#endif


// -------------------------------------------------------------------
// Declaration of functions for allocating arrays and matrices
// -------------------------------------------------------------------

iArray *allocIntArray(int i);
dArray *allocDoubleArray(int i);
iMatrix *allocIntMatrix(int x, int y);
dMatrix *allocDoubleMatrix(int x, int y);
lInfo *allocLikeInfo(int num_snps);


// -------------------------------------------------------------------
// Declaration of functions for rearranging arrays and matrices
// -------------------------------------------------------------------

iMatrix* transpose_matrix(iMatrix *m, bool freeold);
iMatrix* format_z_matrix(iMatrix *m, bool freeold);
iMatrix* limit_matrix(iMatrix *m, int firstindex, int lastindex, bool freeold);
dMatrix* limit_matrix(dMatrix *m, int firstindex, int lastindex, bool freeold);


// -------------------------------------------------------------------
// Delclaration of functions for deallocating arrays and matrices
// -------------------------------------------------------------------

void killArray(iArray *var);
void killArray(dArray *var);
void killMatrix(iMatrix *var);
void killMatrix(dMatrix *var);
void killLikeInfo(lInfo *var);



