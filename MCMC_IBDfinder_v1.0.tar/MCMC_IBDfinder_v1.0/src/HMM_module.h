/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// HMM Module header:
// Implements functionality to work with an HMM that models
// IBD sets in SNPs from numerous individuals of unknown relation
//
// Implemented by Ida Moltke, fall 2008 - fall 2010
// -------------------------------------------------------------------


// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#ifndef _types_h
#define _types_h
#include "types.h"
#endif


// -------------------------------------------------------------------
// Help functions
// -------------------------------------------------------------------

int get_bit_value(int dec_num, int bit_number);
dMatrix* make_error_prob_table(double eps);


// -------------------------------------------------------------------
// Functions for calculating emission probabilities
// -------------------------------------------------------------------

dMatrix *make_e_table_no_u(dMatrix *error_table);
dMatrix *make_e_table_with_u(int num_snps,dMatrix *frac_table,dMatrix *error_table);
double calc_e(int first_locus,int last_locus,iMatrix *genos,
	      iMatrix *zs,int k,
	      int num_inds,dMatrix *frac_table,dArray *log_es,
	      iArray *yi, dMatrix *e_table_with_u,
	      dMatrix *e_table_no_u);



//--------------------------------------------------------------------
// Functions for calculating transition probabilities
//--------------------------------------------------------------------

double calc_t(int first,int last,dArray *t_diffs,iMatrix *zs,int k,
	      double lam,double rho,int num_inds,dArray *log_ts);

double calc_t_1chr(int first_locus,int last_locus,dArray *t_diffs,
		   iMatrix *zs,int k, double lam,double rho,
		   int num_inds,dArray *log_ts,int chr);


