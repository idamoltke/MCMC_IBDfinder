/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/


// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// Type def file:
// Defines the types used in this software package
//
// Implemented by Ida Moltke, fall 2007 - fall 2010
// (based on code by Thorfinn Sand Korneliussen)
// -------------------------------------------------------------------


typedef struct{
  int x;
  int* array;
}iArray;


typedef struct {
  int x;
  double* array;
}dArray;


typedef struct  {
  int x;
  int y;
  int** matrix;
}iMatrix ;


typedef struct{
  int x;
  int y;
  double** matrix;
} dMatrix ;


typedef struct {
  double log_t;
  double log_e;
  dArray *log_ts;
  dArray *tmp_log_ts;
  dArray *tmp2_log_ts;
  dArray *log_es;
  dArray *tmp_log_es;
}lInfo;


typedef struct{
  double half_window_size_lam;
  double half_window_size_rho;
  int max_len_5;
  int max_len_6;
  int max_len_7;
  int max_len_8;
  int max_len_9;
  int max_len_10;
  int max_len_11;
  int max_len_12;
  int max_len_13;
}move_pars;



/* typedef struct{ */
/*   double half_window_size_lam; */
/*   double half_window_size_rho; */
/*   int max_reg_size5; */
/*   int max_reg_size6; */
/*   int max_reg_size7; */
/*   int max_reg_size8; */
/*   int max_reg_size9; */
/*   int max_reg_size10; */
/*   int max_reg_size11; */
/* }move_pars; */
