/*                                                                              
  Copyright (C) 2010 Ida Moltke       ida@binf.ku.dk            
                                                                                
  This file is part of MCMC_IBDfinder v1.0                                              
                                                                                
  MCMC_IBDfinder is free software: you can redistribute it and/or modify                 
  it under the terms of the GNU General Public License as published by          
  the Free Software Foundation, either version 3 of the License, or             
  (at your option) any later version.                                           
                                                                                
  MCMC_IBDfinder is distributed in the hope that it will be useful,                     
  but WITHOUT ANY WARRANTY; without even the implied warranty of                
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                 
  GNU General Public License for more details.                                  
                                                                                
  You should have received a copy of the GNU General Public License             
  along with MCMC_IBDfinder.  If not, see <http://www.gnu.org/licenses/>.                
*/



// -------------------------------------------------------------------
// MCMC IBDfinder source code - program version 1.0
// -------------------------------------------------------------------
// Main:
// Implements functionality to read in commandline arguments and
// start up MCMC with the relevant parameters
//
// Implemented by Ida Moltke, fall 2007 - fall 2010
// -------------------------------------------------------------------


// -------------------------------------------------------------------
// Includes
// -------------------------------------------------------------------

#include <algorithm>
#include <iostream>
#include "io.h"
#include "alloc.h"
#include "MCMC_module.h"
#include "stdio.h"
#include "string.h"

#ifndef _types_h
#define _types_h
#include "types.h"
#endif


using namespace std;

// -------------------------------------------------------------------
// Help functions for handling commandline arguments
// -------------------------------------------------------------------

typedef struct{
  const char *geno_filename;
  const char *posmaf_filename;
  const char *init_z_filename;
  const char *out_filename;
  double init_rho;
  double init_lam;
  int k;
  int num_its;
  int first_snp;
  int num_snps;
  iArray *num_moves_in_it;
  double eps;
  int thinning;
  int seed;
  int hom_fixed_start;
  int het_fixed_start;
}program_pars;



void print_program_pars(program_pars *pars,int num_move_types,string move_types[]){
  
  printf("Data parameters\n");
  printf("-g\tName of file with genotypes\t\t%s\n",pars->geno_filename);
  printf("-p\tName of file with pos maf info\t\t%s\n",pars->posmaf_filename);
  
  printf("\nInitialisation parameters\n");
  printf("-z\tInitial value of z (filename)\t\t%s\n",pars->init_z_filename);
  printf("-l\tInitial value of lambda\t\t\t%f\n",pars->init_lam);
  printf("-r\tInitial value of rho \t\t\t%f\n",pars->init_rho);
  printf("-s\tSeed for random numbers\t\t\t%d\n",pars->seed);


  printf("\nRun parameters\n");
  printf("-e\tGenotyping error rate on allele level\t%f\n",pars->eps);
  printf("-f\tIndex of first SNP\t\t\t%d\n",pars->first_snp);
  
  if(pars->k==-1){
    printf("-k\tMax number of IBD sets\t\t\tNumber of chromosomes\n");
  }
  else{
    printf("-k\tMax number of IBD sets\t\t\t%d\n",pars->k);
  }
  printf("-ni\tNumber of iterations\t\t\t%d\n",pars->num_its);

  if(pars->num_snps==-1){
    printf("-ns\tNumber of SNPs to include in MCMC\tAll\n");
  }
  else{
    printf("-ns\tNumber of SNPs to include in MCMC\t%d\n",pars->num_snps);
  } 

  printf("\nMove parameters\n"); 
  for(int j=0;j<num_move_types;j++){
    cout << "-n" << move_types[j] << "\tNumber of moves of type ";
    cout << move_types[j] << "\t\t";
    cout << pars->num_moves_in_it->array[j] << endl;
  }
  


  printf("\nOutput parameters\n"); 
  if(strlen(pars->out_filename)==0){
    printf("-o\tOutput destination (filename/screen)\tScreen\n");
  }else{
    printf("-o\tOutput destination\t\t\t%s\n",pars->out_filename);
  }
  printf("-t\tThinning t (print every t iteration)\t%d\n",pars->thinning);


}


// -------------------------------------------------------------------
// Main
// -------------------------------------------------------------------

int main(int argc,char *argv[]){


  // Initialising default program parameters
  using std::string;
  program_pars *p_pars = new program_pars();

  const int num_move_types = 13;
  string move_types[num_move_types]; 
  move_types[0]  = "l";
  move_types[1]  = "r";
  move_types[2]  = "lw";
  move_types[3]  = "rw";
  move_types[4]  = "zreg";
  move_types[5]  = "z";
  move_types[6]  = "zbor";
  move_types[7]  = "zmreg";
  move_types[8]  = "zxorr";
  move_types[9]  = "znes";
  move_types[10] = "zsnes";
  move_types[11] = "zcp";
  move_types[12] = "zbc";

  p_pars->geno_filename   = "";
  p_pars->posmaf_filename = "";
  p_pars->init_z_filename = "";
  p_pars->out_filename = "";
  p_pars->init_rho=0.2;
  p_pars->init_lam=0.2;
  p_pars->k=2;
  p_pars->first_snp=0;
  p_pars->num_its=10;
  p_pars->num_snps=-1;  
  p_pars->num_moves_in_it = allocIntArray(num_move_types);

  // default mix of moves
  p_pars->num_moves_in_it->array[0]=0;
  p_pars->num_moves_in_it->array[1]=0;
  p_pars->num_moves_in_it->array[2]=1;
  p_pars->num_moves_in_it->array[3]=1;
  p_pars->num_moves_in_it->array[4]=350;
  p_pars->num_moves_in_it->array[5]=150;
  p_pars->num_moves_in_it->array[6]=200;  
  p_pars->num_moves_in_it->array[7]=0;
  p_pars->num_moves_in_it->array[8]=150;
  p_pars->num_moves_in_it->array[9]=0;
  p_pars->num_moves_in_it->array[10]=0;
  p_pars->num_moves_in_it->array[11]=50;
  p_pars->num_moves_in_it->array[12]=100;

  p_pars->eps=0.01;
  p_pars->thinning=1;
  p_pars->seed=0;
  p_pars->hom_fixed_start=-1;
  p_pars->het_fixed_start=-1;

  // Getting all program parameter values from commandline
  if (argc%2==0){
    printf("\nHELP\nYou are running MCMC_IBDfinder version 1.0\nThe program parameters are per default set to\n\n");
    print_program_pars(p_pars,num_move_types,move_types);
    printf("\nIf other values are wanted then set these when the program is run\n");
    killArray(p_pars->num_moves_in_it);
    delete p_pars;
    return 0;
  }

  string arg;
  bool move_arg;

  for (int i=1;i<argc;i+=2){
    arg=argv[i];
    // checking for all other args than move numbers
    if (arg.compare("-g")==0)
      p_pars->geno_filename=argv[i+1];
    else if(arg.compare("-p")==0)
      p_pars->posmaf_filename=argv[i+1];
    else if(arg.compare("-z")==0)
      p_pars->init_z_filename=argv[i+1];
    else if(arg.compare("-l")==0)
      p_pars->init_lam=atof(argv[i+1]);
    else if(arg.compare("-r")==0)
      p_pars->init_rho=atof(argv[i+1]);
    else if(arg.compare("-ni")==0)
      p_pars->num_its=atoi(argv[i+1]);
    else if(arg.compare("-k")==0)
      p_pars->k=atoi(argv[i+1]);
    else if(arg.compare("-f")==0)
      p_pars->first_snp=atoi(argv[i+1]);
    else if(arg.compare("-ns")==0)
      p_pars->num_snps=atoi(argv[i+1]);
    else if(arg.compare("-e")==0)
      p_pars->eps=atof(argv[i+1]);
    else if(arg.compare("-t")==0)
      p_pars->thinning=atoi(argv[i+1]);
    else if(arg.compare("-s")==0)
      p_pars->seed=atoi(argv[i+1]);
    else if(arg.compare("-homfix")==0){
      if(p_pars->het_fixed_start==-1){
	p_pars->hom_fixed_start=atoi(argv[i+1]);
      }else{
	printf("You can not set both -homfix AND -hetfix.\nWill exit now\n");
	exit(EXIT_FAILURE);
      }
    }
    else if(arg.compare("-hetfix")==0){
      if(p_pars->hom_fixed_start==-1){
	p_pars->het_fixed_start=atoi(argv[i+1]);
      }else{
	printf("You can not set both -homfix AND -hetfix.\nWill exit now\n");
	exit(EXIT_FAILURE);
      }
    }
    else if(arg.compare("-o")==0) 
      p_pars->out_filename=argv[i+1];
    else{
      // if it is not categorized as something else
      // all move args are checked 
      move_arg = false;
      for(int j=0;j<num_move_types;j++){
	if(arg.compare("-n"+move_types[j])==0){
	  p_pars->num_moves_in_it->array[j]=atoi(argv[i+1]);
	  move_arg = true;
	}
      }
      // and if it is not such an arg either an 
      // error message is returned
      if(not(move_arg)){
	printf("\t\tUnknown argument \t%s\n\t\tWill exit now\n",argv[i]);
	exit(EXIT_FAILURE);
      }
    }
  }

  // making -g, -p and -z mandatory
  if(strlen(p_pars->geno_filename)==0){
    	printf("\t\tYou must indicate a valid genotype filename using the option flag -g\t\n\t\tWill exit now\n");
	exit(EXIT_FAILURE);
  }
  if(strlen(p_pars->posmaf_filename)==0){
    	printf("\t\tYou must indicate a valid posmaf filename using the option flag -p\t\n\t\tWill exit now\n");
	exit(EXIT_FAILURE);
  }
  if(strlen(p_pars->init_z_filename)==0){
    	printf("\t\tYou must indicate a valid initz filename using the option flag -z\t\n\t\tWill exit now\n");
	exit(EXIT_FAILURE);
  }


  // Getting and reformatting info based on parameters

  // - info extraction
  iMatrix *raw_geno_matrix = get_i_data(p_pars->geno_filename);
  dMatrix *raw_pos_maf_matrix = get_d_data(p_pars->posmaf_filename);
  iMatrix *raw_init_z_matrix = get_i_data(p_pars->init_z_filename);
  int k = p_pars->k;
  int n = p_pars->num_its;
  double rho = p_pars->init_rho;
  double lam = p_pars->init_lam;
  int first_snp = p_pars->first_snp;
  int num_snps_wanted = p_pars->num_snps;
  double eps =  p_pars->eps;
  int thinning = p_pars->thinning;
  int seed = p_pars->seed;
  iArray *num_moves_in_it = p_pars->num_moves_in_it; 
  
  // - formatting data and making basic checks
  int num_snps_in_geno = raw_geno_matrix->y;
  if(num_snps_in_geno!=raw_pos_maf_matrix->y){
    printf("\nThe number of snps in the genotype file does not match the number of snps that the posmaf file contains information about\nWill exit now\n");
    killArray(p_pars->num_moves_in_it);
    delete p_pars;
    killMatrix(raw_geno_matrix);
    killMatrix(raw_pos_maf_matrix);
    killMatrix(raw_init_z_matrix);
    exit(EXIT_FAILURE);
  }
  if((num_snps_in_geno*2)!=raw_init_z_matrix->y){
    printf("\nThe number of snps in the genotype file does not match the number of snps that the initz file contains information about\nWill exit now\n");
    killArray(p_pars->num_moves_in_it);
    delete p_pars;
    killMatrix(raw_geno_matrix);
    killMatrix(raw_pos_maf_matrix);
    killMatrix(raw_init_z_matrix);
    exit(EXIT_FAILURE);
  }

  int num_inds = raw_geno_matrix->x;
  int num_chrs = num_inds*2;
  if(num_inds!=raw_init_z_matrix->x){
    printf("\nThe number of individuals in the genotype file does not match the number of individuals that the initz file contains information about\nWill exit now\n");
    killArray(p_pars->num_moves_in_it);
    delete p_pars;
    killMatrix(raw_geno_matrix);
    killMatrix(raw_pos_maf_matrix);
    killMatrix(raw_init_z_matrix);
    exit(EXIT_FAILURE);
  }

  int num_snps;
  if(num_snps_wanted<0){
    if(first_snp == 0){
      num_snps = num_snps_in_geno;
    }
    else{
      num_snps = num_snps_in_geno-first_snp+1;
    }
  }
  else{
    if((first_snp+num_snps_wanted)>(num_snps_in_geno)){
      printf("\nThe number of snps wanted exceeds what is available in the geno type matrix\n\t\tWill exit now\n");
      killArray(p_pars->num_moves_in_it);
      delete p_pars;
      killMatrix(raw_geno_matrix);
      killMatrix(raw_pos_maf_matrix);
      killMatrix(raw_init_z_matrix);
      exit(EXIT_FAILURE);
    }
    else{
      num_snps = num_snps_wanted;
    }
  }  
  int l_limit = first_snp;
  int r_limit = first_snp+num_snps-1;
  

  iMatrix *genos_tmp = limit_matrix(raw_geno_matrix,l_limit,r_limit,true);
  iMatrix *genos = transpose_matrix(genos_tmp,true);
 
  iMatrix *zs_tmp1 = format_z_matrix(raw_init_z_matrix,true);
  iMatrix *zs_tmp2 = limit_matrix(zs_tmp1,l_limit,r_limit,true);
  iMatrix *zs = transpose_matrix(zs_tmp2,true);
 
  dMatrix *pos_maf = limit_matrix(raw_pos_maf_matrix,l_limit,r_limit,true);
  
  dArray *t_diffs = allocDoubleArray(num_snps);
  t_diffs->array[0]=0;
  for(int i=1;i<num_snps;i++){
    t_diffs->array[i]=pos_maf->matrix[0][i]-pos_maf->matrix[0][i-1];
  }
  dMatrix *frac_table = allocDoubleMatrix(num_snps,2);
  for(int i=0;i<num_snps;i++){
    frac_table->matrix[i][0] = 1-pos_maf->matrix[1][i];
    frac_table->matrix[i][1] = pos_maf->matrix[1][i];
  }
  killMatrix(pos_maf);

  if(k<1){
    k = num_chrs; 
  }

  // Redirecting output to file if requested
  FILE *fp;
  bool fpopen = false;
  if(strlen(p_pars->out_filename)>0){
    if((fp=freopen(p_pars->out_filename,"w",stdout))==NULL){
      printf("Cannot open output file, output is therefore printed to screen\n");
    }else{
      fpopen=true;
    }
  }
  printf("You are running MCMC_IBDfinder version 1.0 with the following parameter values:\n\n");  
  print_program_pars(p_pars,num_move_types,move_types);
  
  // Init pars
  move_pars *m_pars = new move_pars();
  m_pars->half_window_size_lam = 0.05;
  m_pars->half_window_size_rho = 0.05;
  m_pars->max_len_5 = min(20,num_snps);
  m_pars->max_len_6 = min(20,num_snps);
  m_pars->max_len_7 = min(20,num_snps);
  m_pars->max_len_8 = min(50,num_snps);
  m_pars->max_len_9 = min(50,num_snps);
  m_pars->max_len_10 = min(20,num_snps);
  m_pars->max_len_11 = min(20,num_snps);
  m_pars->max_len_12 = min(50,num_snps);

  // init fix info 
  if(p_pars->hom_fixed_start>-1){
    // fix all chromosomes
    iArray *fixed_chrs = allocIntArray(num_chrs);
    for(int i=0;i<num_chrs;i++){
      fixed_chrs->array[i]=i;
    }
    int fixed_region_start = p_pars->hom_fixed_start;
    int num_fixed = 1;
    
    // Start fixed MCMC
    printf("\nFixed MCMC has been started...\n\n");
    MCMC_fixed(fixed_chrs,fixed_region_start,num_fixed,k,
	       genos,t_diffs,frac_table,eps,thinning,n,
	       zs,lam,rho,num_moves_in_it,seed,m_pars);
    killArray(fixed_chrs);
  }else{
    if(p_pars->het_fixed_start>-1){
      // fix every second chromosome
      iArray *fixed_chrs = allocIntArray(num_chrs/2);
      for(int i=0;i<num_chrs;i+=2){
	fixed_chrs->array[i/2]=i;
      }
      int fixed_region_start = p_pars->het_fixed_start;
      int num_fixed = 1;
      
      // Start fixed MCMC
      printf("\nFixed MCMC has been started...\n\n");
      MCMC_fixed(fixed_chrs,fixed_region_start,num_fixed,k,
		 genos,t_diffs,frac_table,eps,thinning,n,
		 zs,lam,rho,num_moves_in_it,seed,m_pars);
      killArray(fixed_chrs);
    }else{
    // Start MCMC
    printf("\nMCMC has been started...\n\n");
    MCMC(k,genos,t_diffs,frac_table,eps,thinning,n,
	 zs,lam,rho,num_moves_in_it,seed,m_pars);
    
    }
  }
  killMatrix(genos);
  killMatrix(zs);
  killArray(t_diffs);
  killMatrix(frac_table);
  killArray(num_moves_in_it);  
  if(fpopen){
    fclose(fp);
  }  
  delete p_pars;
  delete m_pars;
  return 0;
}







